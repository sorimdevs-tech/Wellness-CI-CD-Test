import { createContext, useContext, useState, useEffect } from "react";

export interface Appointment {
  id: string;
  doctorId: string;
  doctorName: string;
  doctorSpecialty: string;
  userId: string;
  userName: string;
  date: string;
  time: string;
  duration: string;
  reason?: string;
  status: "pending" | "confirmed" | "completed" | "cancelled";
  createdAt: string;
}

export interface Notification {
  id: string;
  type: "appointment_booked" | "appointment_confirmed" | "appointment_cancelled";
  title: string;
  message: string;
  recipientId: string;
  recipientType: "user" | "doctor";
  appointmentId?: string;
  read: boolean;
  createdAt: string;
}

interface AppointmentContextType {
  appointments: Appointment[];
  notifications: Notification[];
  bookAppointment: (
    doctorId: string,
    doctorName: string,
    doctorSpecialty: string,
    userId: string,
    userName: string,
    date: string,
    time: string,
    duration: string,
    reason: string
  ) => void;
  confirmAppointment: (appointmentId: string) => void;
  cancelAppointment: (appointmentId: string) => void;
  getNotifications: (userId: string, userType: "user" | "doctor") => Notification[];
  markNotificationAsRead: (notificationId: string) => void;
  clearNotifications: (userId: string, userType: "user" | "doctor") => void;
}

const AppointmentContext = createContext<AppointmentContextType | undefined>(
  undefined
);

export function AppointmentProvider({
  children,
}: {
  children: React.ReactNode;
}) {
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);

  // Load from localStorage on mount
  useEffect(() => {
    const savedAppointments = localStorage.getItem("appointments");
    const savedNotifications = localStorage.getItem("notifications");

    if (savedAppointments) {
      try {
        setAppointments(JSON.parse(savedAppointments));
      } catch (e) {
        console.error("Failed to load appointments:", e);
      }
    }

    if (savedNotifications) {
      try {
        setNotifications(JSON.parse(savedNotifications));
      } catch (e) {
        console.error("Failed to load notifications:", e);
      }
    }
  }, []);

  // Save appointments to localStorage
  useEffect(() => {
    localStorage.setItem("appointments", JSON.stringify(appointments));
  }, [appointments]);

  // Save notifications to localStorage
  useEffect(() => {
    localStorage.setItem("notifications", JSON.stringify(notifications));
  }, [notifications]);

  const bookAppointment = (
    doctorId: string,
    doctorName: string,
    doctorSpecialty: string,
    userId: string,
    userName: string,
    date: string,
    time: string,
    duration: string,
    reason: string
  ) => {
    const appointmentId = `apt_${Date.now()}`;
    const newAppointment: Appointment = {
      id: appointmentId,
      doctorId,
      doctorName,
      doctorSpecialty,
      userId,
      userName,
      date,
      time,
      duration,
      reason,
      status: "pending",
      createdAt: new Date().toISOString(),
    };

    setAppointments((prev) => [...prev, newAppointment]);

    // Create notification for doctor
    const doctorNotification: Notification = {
      id: `notif_${Date.now()}_doctor`,
      type: "appointment_booked",
      title: "New Appointment Request",
      message: `${userName} has requested an appointment on ${date} at ${time} for ${reason}`,
      recipientId: doctorId,
      recipientType: "doctor",
      appointmentId,
      read: false,
      createdAt: new Date().toISOString(),
    };

    // Create notification for user
    const userNotification: Notification = {
      id: `notif_${Date.now()}_user`,
      type: "appointment_booked",
      title: "Appointment Requested",
      message: `Your appointment with Dr. ${doctorName} has been requested for ${date} at ${time}. Awaiting confirmation.`,
      recipientId: userId,
      recipientType: "user",
      appointmentId,
      read: false,
      createdAt: new Date().toISOString(),
    };

    console.log("📋 BOOKING APPOINTMENT:", {
      appointmentId,
      doctorId,
      userId,
      doctorNotification,
      userNotification,
    });

    setNotifications((prev) => [doctorNotification, userNotification, ...prev]);
  };

  const confirmAppointment = (appointmentId: string) => {
    // Find appointment first before updating state
    const appointmentToConfirm = appointments.find((apt) => apt.id === appointmentId);
    if (!appointmentToConfirm) return;

    setAppointments((prev) =>
      prev.map((apt) =>
        apt.id === appointmentId ? { ...apt, status: "confirmed" } : apt
      )
    );

    // Notification for user
    const userNotification: Notification = {
      id: `notif_${Date.now()}_confirmed_user`,
      type: "appointment_confirmed",
      title: "Appointment Confirmed",
      message: `Your appointment with Dr. ${appointmentToConfirm.doctorName} on ${appointmentToConfirm.date} at ${appointmentToConfirm.time} has been confirmed!`,
      recipientId: appointmentToConfirm.userId,
      recipientType: "user",
      appointmentId,
      read: false,
      createdAt: new Date().toISOString(),
    };

    setNotifications((prev) => [userNotification, ...prev]);
  };

  const cancelAppointment = (appointmentId: string) => {
    // Find appointment first before updating state
    const appointmentToCancel = appointments.find((apt) => apt.id === appointmentId);
    if (!appointmentToCancel) return;

    setAppointments((prev) =>
      prev.map((apt) =>
        apt.id === appointmentId ? { ...apt, status: "cancelled" } : apt
      )
    );

    // Notification for user
    const userNotification: Notification = {
      id: `notif_${Date.now()}_cancelled_user`,
      type: "appointment_cancelled",
      title: "Appointment Cancelled",
      message: `Your appointment with Dr. ${appointmentToCancel.doctorName} on ${appointmentToCancel.date} at ${appointmentToCancel.time} has been cancelled.`,
      recipientId: appointmentToCancel.userId,
      recipientType: "user",
      appointmentId,
      read: false,
      createdAt: new Date().toISOString(),
    };

    setNotifications((prev) => [userNotification, ...prev]);
  };

  const getNotifications = (
    userId: string,
    userType: "user" | "doctor"
  ): Notification[] => {
    const filtered = notifications.filter(
      (notif) => notif.recipientId === userId && notif.recipientType === userType
    );
    console.log("🔔 GET NOTIFICATIONS:", {
      userId,
      userType,
      totalNotifications: notifications.length,
      filteredCount: filtered.length,
      filtered,
    });
    return filtered;
  };

  const markNotificationAsRead = (notificationId: string) => {
    setNotifications((prev) =>
      prev.map((notif) =>
        notif.id === notificationId ? { ...notif, read: true } : notif
      )
    );
  };

  const clearNotifications = (userId: string, userType: "user" | "doctor") => {
    setNotifications((prev) =>
      prev.filter(
        (notif) =>
          !(
            notif.recipientId === userId &&
            notif.recipientType === userType
          )
      )
    );
  };

  return (
    <AppointmentContext.Provider
      value={{
        appointments,
        notifications,
        bookAppointment,
        confirmAppointment,
        cancelAppointment,
        getNotifications,
        markNotificationAsRead,
        clearNotifications,
      }}
    >
      {children}
    </AppointmentContext.Provider>
  );
}

export function useAppointment() {
  const context = useContext(AppointmentContext);
  if (context === undefined) {
    throw new Error(
      "useAppointment must be used within AppointmentProvider"
    );
  }
  return context;
}
