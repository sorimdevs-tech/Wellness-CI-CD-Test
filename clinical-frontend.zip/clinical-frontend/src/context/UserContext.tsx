import React, { createContext, useState, useContext, useEffect } from "react";

interface User {
  id?: string;
  name: string;
  email?: string;
  mobile?: string;
  phone?: string;
  userType: "user" | "doctor";
  currentRole: "user" | "doctor";
  regNumber?: string;
  avatar?: string;
  dateOfBirth?: string;
  address?: string;
  city?: string;
  state?: string;
  zipCode?: string;
  bloodType?: string;
  emergencyContact?: string;
}

interface Session {
  loginTime: string;
  lastActivityTime: string;
  sessionDuration: number; // in minutes
  isActive: boolean;
  deviceInfo: string;
}

interface UserContextType {
  user: User | null;
  session: Session | null;
  setUser: (user: User | null) => void;
  switchRole: (role: "user" | "doctor") => void;
  logout: () => void;
  createSession: (user: User) => void;
  updateActivity: () => void;
  getSessionDuration: () => number;
  getSessionTimeRemaining: () => number;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

export function UserProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);

  // Load user and session from localStorage on mount
  useEffect(() => {
    const userType = localStorage.getItem("userType") as "user" | "doctor" | null;
    const userName = localStorage.getItem("userName");
    const userEmail = localStorage.getItem("userEmail");
    const userMobile = localStorage.getItem("userMobile");
    const sessionData = localStorage.getItem("sessionData");

    if (userType && userName) {
      const userData: User = {
        name: userName,
        email: userEmail || undefined,
        mobile: userMobile || undefined,
        userType: userType,
        currentRole: (localStorage.getItem("currentRole") as "user" | "doctor") || userType,
        regNumber: localStorage.getItem("regNumber") || undefined,
        avatar: localStorage.getItem("userAvatar") || undefined,
      };
      setUser(userData);

      if (sessionData) {
        const parsedSession = JSON.parse(sessionData);
        // Check if session is still valid (24 hours)
        const loginTime = new Date(parsedSession.loginTime);
        const now = new Date();
        const diffInMs = now.getTime() - loginTime.getTime();
        const diffInMinutes = diffInMs / (1000 * 60);

        if (diffInMinutes < 1440) { // 24 hours
          setSession(parsedSession);
        } else {
          // Session expired
          localStorage.removeItem("sessionData");
        }
      }
    }
  }, []);

  // Activity listener for session updates
  useEffect(() => {
    const handleActivity = () => {
      updateActivity();
    };

    window.addEventListener("mousemove", handleActivity);
    window.addEventListener("keypress", handleActivity);
    window.addEventListener("click", handleActivity);

    return () => {
      window.removeEventListener("mousemove", handleActivity);
      window.removeEventListener("keypress", handleActivity);
      window.removeEventListener("click", handleActivity);
    };
  }, [session]);

  // Handle page unload to clear session
  useEffect(() => {
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      if (user && session) {
        // Don't actually logout on page refresh, just warn if session is about to expire
        const timeRemaining = getSessionTimeRemaining();
        if (timeRemaining < 5) {
          e.preventDefault();
          e.returnValue = "";
        }
      }
    };

    window.addEventListener("beforeunload", handleBeforeUnload);
    return () => window.removeEventListener("beforeunload", handleBeforeUnload);
  }, [user, session]);

  const createSession = (userData: User) => {
    const now = new Date();
    const newSession: Session = {
      loginTime: now.toISOString(),
      lastActivityTime: now.toISOString(),
      sessionDuration: 480, // 8 hours
      isActive: true,
      deviceInfo: `${navigator.platform} - ${navigator.userAgent.substring(0, 50)}`,
    };

    setSession(newSession);
    localStorage.setItem("sessionData", JSON.stringify(newSession));
  };

  const updateActivity = () => {
    if (session) {
      const updatedSession = {
        ...session,
        lastActivityTime: new Date().toISOString(),
      };
      setSession(updatedSession);
      localStorage.setItem("sessionData", JSON.stringify(updatedSession));
    }
  };

  const getSessionDuration = (): number => {
    if (!session) return 0;
    const loginTime = new Date(session.loginTime);
    const now = new Date();
    const diffInMs = now.getTime() - loginTime.getTime();
    return Math.floor(diffInMs / (1000 * 60)); // in minutes
  };

  const getSessionTimeRemaining = (): number => {
    if (!session) return 0;
    const sessionDurationMs = session.sessionDuration * 60 * 1000; // Convert to milliseconds
    const loginTime = new Date(session.loginTime);
    const now = new Date();
    const elapsedMs = now.getTime() - loginTime.getTime();
    const remainingMs = sessionDurationMs - elapsedMs;
    return Math.floor(remainingMs / (1000 * 60)); // in minutes
  };

  const switchRole = (role: "user" | "doctor") => {
    if (user) {
      const updatedUser = { ...user, currentRole: role };
      setUser(updatedUser);
      localStorage.setItem("currentRole", role);
    }
  };

  const logout = () => {
    setUser(null);
    setSession(null);
    localStorage.removeItem("userType");
    localStorage.removeItem("userName");
    localStorage.removeItem("userEmail");
    localStorage.removeItem("userMobile");
    localStorage.removeItem("currentRole");
    localStorage.removeItem("regNumber");
    localStorage.removeItem("userAvatar");
    localStorage.removeItem("sessionData");
  };

  return (
    <UserContext.Provider
      value={{
        user,
        session,
        setUser,
        switchRole,
        logout,
        createSession,
        updateActivity,
        getSessionDuration,
        getSessionTimeRemaining,
      }}
    >
      {children}
    </UserContext.Provider>
  );
}

export function useUser() {
  const context = useContext(UserContext);
  if (context === undefined) {
    throw new Error("useUser must be used within UserProvider");
  }
  return context;
}
