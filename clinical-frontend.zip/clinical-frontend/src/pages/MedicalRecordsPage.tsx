import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useUser } from "../context/UserContext";
import Header from "../components/Header";
import Footer from "../components/Footer";

interface MedicalRecord {
  id: number;
  type: string;
  title: string;
  date: string;
  doctor: string;
  description: string;
  category: "report" | "prescription" | "test" | "diagnosis" | "vaccination" | "other";
  files: Array<{
    name: string;
    type: string;
    size: number;
    uploadDate: string;
    data?: string; // Base64 encoded file
  }>;
}

export default function MedicalRecordsPage() {
  const navigate = useNavigate();
  const { user, logout } = useUser();
  const [records, setRecords] = useState<MedicalRecord[]>([
    {
      id: 1,
      type: "Lab Report",
      title: "Blood Test Report",
      date: "2025-12-10",
      doctor: "Dr. Rajesh Kumar",
      description: "Complete blood count and biochemistry test",
      category: "report",
      files: [
        {
          name: "blood_test_report.pdf",
          type: "application/pdf",
          size: 245000,
          uploadDate: "2025-12-10",
        },
      ],
    },
    {
      id: 2,
      type: "Prescription",
      title: "Medications for Hypertension",
      date: "2025-12-08",
      doctor: "Dr. Priya Singh",
      description: "Monthly medications for blood pressure management",
      category: "prescription",
      files: [
        {
          name: "prescription_hypertension.pdf",
          type: "application/pdf",
          size: 128000,
          uploadDate: "2025-12-08",
        },
      ],
    },
    {
      id: 3,
      type: "Test Result",
      title: "COVID-19 RT-PCR Test",
      date: "2025-12-05",
      doctor: "Lab Technician",
      description: "COVID-19 Testing",
      category: "test",
      files: [
        {
          name: "covid_test_result.pdf",
          type: "application/pdf",
          size: 156000,
          uploadDate: "2025-12-05",
        },
      ],
    },
  ]);

  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [formData, setFormData] = useState({
    type: "",
    title: "",
    date: new Date().toISOString().split("T")[0],
    doctor: "",
    description: "",
    category: "report" as const,
  });
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterCategory, setFilterCategory] = useState("all");

  const categories = [
    { id: "all", name: "All Records" },
    { id: "report", name: "Lab Reports", icon: "📄" },
    { id: "prescription", name: "Prescriptions", icon: "💊" },
    { id: "test", name: "Test Results", icon: "🧪" },
    { id: "diagnosis", name: "Diagnosis", icon: "🩺" },
    { id: "vaccination", name: "Vaccinations", icon: "💉" },
    { id: "other", name: "Other", icon: "📋" },
  ];

  const filteredRecords = records.filter((record) => {
    const matchesSearch = record.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      record.doctor.toLowerCase().includes(searchTerm.toLowerCase()) ||
      record.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = filterCategory === "all" || record.category === filterCategory;
    return matchesSearch && matchesCategory;
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Convert files to file objects
    const filesArray = selectedFiles.map(file => ({
      name: file.name,
      type: file.type,
      size: file.size,
      uploadDate: new Date().toISOString().split("T")[0],
    }));

    if (editingId) {
      setRecords(records.map(r => 
        r.id === editingId 
          ? { 
              ...r, 
              ...formData, 
              files: filesArray.length > 0 ? filesArray : r.files,
              id: editingId 
            }
          : r
      ));
      setEditingId(null);
    } else {
      const newRecord: MedicalRecord = {
        id: Math.max(...records.map(r => r.id), 0) + 1,
        ...formData,
        files: filesArray,
      };
      setRecords([newRecord, ...records]);
    }
    
    resetForm();
    setShowForm(false);
  };

  const resetForm = () => {
    setFormData({
      type: "",
      title: "",
      date: new Date().toISOString().split("T")[0],
      doctor: "",
      description: "",
      category: "report",
    });
    setSelectedFiles([]);
  };

  const handleEdit = (record: MedicalRecord) => {
    setFormData({
      type: record.type,
      title: record.title,
      date: record.date,
      doctor: record.doctor,
      description: record.description,
      category: record.category as any,
    });
    setEditingId(record.id);
    setShowForm(true);
  };

  const handleDelete = (id: number) => {
    if (confirm("Are you sure you want to delete this record?")) {
      setRecords(records.filter(r => r.id !== id));
    }
  };

  const getCategoryIcon = (category: string) => {
    const cat = categories.find(c => c.id === category);
    return cat?.icon || "📋";
  };

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      report: "bg-blue-100 text-blue-700",
      prescription: "bg-green-100 text-green-700",
      test: "bg-purple-100 text-purple-700",
      diagnosis: "bg-red-100 text-red-700",
      vaccination: "bg-yellow-100 text-yellow-700",
      other: "bg-gray-100 text-gray-700",
    };
    return colors[category] || "bg-gray-100 text-gray-700";
  };

  return (
    <div className="min-h-screen bg-white flex flex-col">
      <Header />

      <div className="max-w-7xl mx-auto px-4 md:px-8 lg:px-12 py-8 flex-1">
        {/* PAGE TITLE SECTION */}
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Medical Records</h1>
            <p className="text-gray-600 mt-1">Manage and organize your health documents</p>
          </div>
          <button
            onClick={() => {
              resetForm();
              setEditingId(null);
              setShowForm(!showForm);
            }}
            className="px-6 py-2.5 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 transition flex items-center gap-2 shadow-lg"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" />
            </svg>
            Add Record
          </button>
        </div>

        {/* ADD/EDIT FORM */}
        {showForm && (
          <div className="mb-12 bg-gradient-to-br from-blue-50 to-blue-100 rounded-3xl p-8 border-2 border-blue-200 shadow-lg">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-gray-900">
                {editingId ? "Edit Medical Record" : "Add New Medical Record"}
              </h2>
              <button
                onClick={() => setShowForm(false)}
                className="text-gray-600 hover:text-gray-900"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Record Type */}
                <div>
                  <label className="block text-sm font-semibold text-gray-900 mb-2">
                    Record Type <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    placeholder="e.g., Lab Report, Prescription"
                    value={formData.type}
                    onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none transition bg-white"
                    required
                  />
                </div>

                {/* Title */}
                <div>
                  <label className="block text-sm font-semibold text-gray-900 mb-2">
                    Title <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    placeholder="e.g., Blood Test Results"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none transition bg-white"
                    required
                  />
                </div>

                {/* Date */}
                <div>
                  <label className="block text-sm font-semibold text-gray-900 mb-2">
                    Date <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="date"
                    value={formData.date}
                    onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none transition bg-white"
                    required
                  />
                </div>

                {/* Doctor Name */}
                <div>
                  <label className="block text-sm font-semibold text-gray-900 mb-2">
                    Doctor/Provider <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    placeholder="e.g., Dr. Rajesh Kumar"
                    value={formData.doctor}
                    onChange={(e) => setFormData({ ...formData, doctor: e.target.value })}
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none transition bg-white"
                    required
                  />
                </div>

                {/* Category */}
                <div>
                  <label className="block text-sm font-semibold text-gray-900 mb-2">
                    Category <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value as any })}
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none transition bg-white"
                    required
                  >
                    <option value="report">Lab Report</option>
                    <option value="prescription">Prescription</option>
                    <option value="test">Test Result</option>
                    <option value="diagnosis">Diagnosis</option>
                    <option value="vaccination">Vaccination</option>
                    <option value="other">Other</option>
                  </select>
                </div>
              </div>

              {/* Description */}
              <div>
                <label className="block text-sm font-semibold text-gray-900 mb-2">
                  Description <span className="text-red-500">*</span>
                </label>
                <textarea
                  placeholder="Add details about this medical record..."
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none transition bg-white resize-none"
                  rows={4}
                  required
                />
              </div>

              {/* FILE UPLOAD */}
              <div>
                <label className="block text-sm font-semibold text-gray-900 mb-2">
                  Upload Documents <span className="text-gray-500">(PDF, Excel, Images, etc.)</span>
                </label>
                <div className="relative">
                  <input
                    type="file"
                    multiple
                    onChange={(e) => {
                      if (e.target.files) {
                        setSelectedFiles(Array.from(e.target.files));
                      }
                    }}
                    accept=".pdf,.doc,.docx,.xls,.xlsx,.jpg,.jpeg,.png,.gif,.bmp,.txt,.csv"
                    className="hidden"
                    id="file-input"
                  />
                  <label
                    htmlFor="file-input"
                    className="flex flex-col items-center justify-center w-full px-4 py-8 border-2 border-dashed border-blue-300 rounded-xl bg-blue-50 cursor-pointer hover:bg-blue-100 transition"
                  >
                    <svg className="w-10 h-10 text-blue-600 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" />
                    </svg>
                    <p className="text-sm font-semibold text-gray-900">Click to upload or drag and drop</p>
                    <p className="text-xs text-gray-600">PDF, Excel, Images, and more</p>
                  </label>
                </div>

                {/* Selected Files List */}
                {selectedFiles.length > 0 && (
                  <div className="mt-4 space-y-2">
                    <p className="text-sm font-semibold text-gray-900">Selected files ({selectedFiles.length}):</p>
                    {selectedFiles.map((file, idx) => (
                      <div key={idx} className="flex items-center justify-between bg-blue-50 p-3 rounded-lg border border-blue-200">
                        <div className="flex items-center gap-3">
                          <svg className="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                          </svg>
                          <div>
                            <p className="text-sm font-semibold text-gray-900">{file.name}</p>
                            <p className="text-xs text-gray-600">{(file.size / 1024).toFixed(2)} KB</p>
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => setSelectedFiles(selectedFiles.filter((_, i) => i !== idx))}
                          className="text-red-600 hover:bg-red-100 p-2 rounded-lg transition"
                        >
                          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                          </svg>
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Form Actions */}
              <div className="flex items-center gap-4 pt-6 border-t-2 border-blue-200">
                <button
                  type="submit"
                  className="px-8 py-3 bg-blue-600 text-white font-bold rounded-lg hover:bg-blue-700 transition shadow-md"
                >
                  {editingId ? "Update Record" : "Add Record"}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowForm(false);
                    resetForm();
                    setEditingId(null);
                  }}
                  className="px-8 py-3 bg-gray-200 text-gray-900 font-bold rounded-lg hover:bg-gray-300 transition"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        )}

        {/* SEARCH AND FILTER */}
        <div className="mb-8 space-y-6">
          {/* Search Bar */}
          <div className="relative">
            <svg className="absolute left-4 top-4 w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
            <input
              type="text"
              placeholder="Search records by title, doctor, or description..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-12 pr-4 py-3 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none transition bg-white"
            />
          </div>

          {/* Category Filter */}
          <div className="flex gap-3 overflow-x-auto pb-2">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setFilterCategory(cat.id)}
                className={`px-4 py-2.5 rounded-full font-semibold transition whitespace-nowrap ${
                  filterCategory === cat.id
                    ? "bg-blue-600 text-white shadow-lg"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                {cat.icon} {cat.name}
              </button>
            ))}
          </div>
        </div>

        {/* RECORDS GRID */}
        {filteredRecords.length === 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredRecords.map((record) => (
              <div
                key={record.id}
                className="bg-white rounded-3xl shadow-lg border border-gray-200 overflow-hidden hover:shadow-2xl hover:-translate-y-1 transition group"
              >
                {/* Header */}
                <div className={`p-6 ${getCategoryColor(record.category)}`}>
                  <div className="flex items-start justify-between mb-3">
                    <span className="text-3xl">{getCategoryIcon(record.category)}</span>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleEdit(record)}
                        className="p-2 text-gray-600 hover:bg-white/20 rounded-lg transition"
                        title="Edit"
                      >
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                        </svg>
                      </button>
                      <button
                        onClick={() => handleDelete(record.id)}
                        className="p-2 text-gray-600 hover:bg-white/20 rounded-lg transition"
                        title="Delete"
                      >
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                        </svg>
                      </button>
                    </div>
                  </div>
                  <h3 className="text-lg font-bold">{record.type}</h3>
                </div>

                {/* Content */}
                <div className="p-6 space-y-4">
                  <div>
                    <h4 className="text-xl font-bold text-gray-900 mb-2">{record.title}</h4>
                    <p className="text-sm text-gray-600">{record.description}</p>
                  </div>

                  <div className="space-y-3 pt-4 border-t border-gray-200">
                    <div className="flex items-center gap-3">
                      <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                      </svg>
                      <span className="text-sm text-gray-700 font-semibold">
                        {new Date(record.date).toLocaleDateString("en-IN", {
                          year: "numeric",
                          month: "short",
                          day: "numeric",
                        })}
                      </span>
                    </div>
                    <div className="flex items-center gap-3">
                      <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" d="M10 6H5a2 2 0 00-2 2v10a2 2 0 002 2h5m4-6l2 2m0 0l2 2m-2-2l-2 2m2-2l2-2" />
                      </svg>
                      <span className="text-sm text-gray-700 font-semibold">{record.doctor}</span>
                    </div>
                  </div>

                  {/* Attached Files Section */}
                  {record.files.length > 0 && (
                    <div className="mt-5 pt-4 border-t border-gray-200">
                      <p className="text-xs font-semibold text-gray-900 mb-3 flex items-center gap-2">
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" />
                        </svg>
                        Attachments ({record.files.length})
                      </p>
                      <div className="space-y-2">
                        {record.files.map((file, idx) => (
                          <div key={idx} className="flex items-center justify-between bg-gray-50 p-3 rounded-lg border border-gray-200 hover:bg-gray-100 transition">
                            <div className="flex items-center gap-2 flex-1 min-w-0">
                              <svg className="w-4 h-4 text-blue-600 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                              </svg>
                              <div className="flex-1 min-w-0">
                                <p className="text-xs font-semibold text-gray-900 truncate">{file.name}</p>
                                <p className="text-xs text-gray-500">{(file.size / 1024).toFixed(2)} KB</p>
                              </div>
                            </div>
                            <button
                              onClick={() => {
                                // Simulate file download
                                const link = document.createElement("a");
                                link.href = "#";
                                link.download = file.name;
                                link.click();
                              }}
                              className="ml-2 p-1.5 text-blue-600 hover:bg-blue-100 rounded transition flex-shrink-0"
                              title="Download"
                            >
                              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                              </svg>
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Add Files Button */}
                  <button
                    onClick={() => handleEdit(record)}
                    className="w-full mt-4 px-4 py-2.5 bg-green-100 text-green-700 font-semibold rounded-lg hover:bg-green-200 transition flex items-center justify-center gap-2"
                  >
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" />
                    </svg>
                    Update Files
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <svg className="w-16 h-16 text-gray-300 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeWidth={1.5} strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
            <h3 className="text-2xl font-bold text-gray-900 mb-2">No Records Found</h3>
            <p className="text-gray-600 mb-6">Add your first medical record to get started</p>
            <button
              onClick={() => {
                resetForm();
                setEditingId(null);
                setShowForm(true);
              }}
              className="px-6 py-2.5 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 transition"
            >
              Add First Record
            </button>
          </div>
        )}

        {/* STATISTICS */}
        {records.length > 0 && (
          <div className="mt-16 pt-12 border-t-2 border-gray-200">
            <h3 className="text-2xl font-bold text-gray-900 mb-8">Your Records Summary</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-2xl p-6 border border-blue-200">
                <p className="text-sm text-blue-700 font-semibold mb-2">Total Records</p>
                <p className="text-3xl font-bold text-blue-900">{records.length}</p>
              </div>
              <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-2xl p-6 border border-green-200">
                <p className="text-sm text-green-700 font-semibold mb-2">Total Files</p>
                <p className="text-3xl font-bold text-green-900">{records.reduce((sum, r) => sum + r.files.length, 0)}</p>
              </div>
              <div className="bg-gradient-to-br from-purple-50 to-purple-100 rounded-2xl p-6 border border-purple-200">
                <p className="text-sm text-purple-700 font-semibold mb-2">Latest Update</p>
                <p className="text-lg font-bold text-purple-900">{records[0]?.date || "N/A"}</p>
              </div>
              <div className="bg-gradient-to-br from-red-50 to-red-100 rounded-2xl p-6 border border-red-200">
                <p className="text-sm text-red-700 font-semibold mb-2">File Types</p>
                <p className="text-lg font-bold text-red-900">
                  {new Set(records.flatMap(r => r.files.map(f => f.type.split("/")[1]?.toUpperCase() || "DOC"))).size}
                </p>
              </div>
            </div>
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
}
