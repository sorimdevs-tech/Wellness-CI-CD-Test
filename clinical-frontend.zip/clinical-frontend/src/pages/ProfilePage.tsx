import { useNavigate } from "react-router-dom";
import { useUser } from "../context/UserContext";
import Footer from "../components/Footer";

export default function ProfilePage() {
  const navigate = useNavigate();
  const { user, logout } = useUser();

  return (
    <div className="min-h-screen bg-white flex flex-col">
      <header className="sticky top-0 z-50 bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 md:px-8 lg:px-12">
          <div className="flex items-center justify-between h-20">
            <div className="flex items-center gap-3 cursor-pointer" onClick={() => navigate("/dashboard")}>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Wellness Dev</h1>
                <p className="text-xs text-gray-500">Healthcare Platform</p>
              </div>
            </div>
            <button onClick={() => navigate(-1)} className="px-4 py-2 bg-gray-200 text-gray-900 rounded-lg hover:bg-gray-300">
              ← Back
            </button>
          </div>
        </div>
      </header>

      <div className="max-w-5xl mx-auto px-4 md:px-8 lg:px-12 py-12 flex-1 w-full">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">My Profile</h1>
          <p className="text-gray-600 text-lg">Your Profile Information</p>
          <div className="mt-10 p-8 bg-gradient-to-br from-blue-50 to-emerald-50 rounded-2xl border border-blue-200 max-w-2xl mx-auto shadow-lg">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <p className="text-sm text-gray-600 font-semibold mb-2">Full Name</p>
                <p className="text-xl font-bold text-gray-900">{user?.name || "User"}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600 font-semibold mb-2">Email</p>
                <p className="text-xl font-bold text-gray-900">{user?.email || "N/A"}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600 font-semibold mb-2">Mobile</p>
                <p className="text-xl font-bold text-gray-900">{user?.mobile || "N/A"}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600 font-semibold mb-2">User Type</p>
                <p className="text-xl font-bold text-blue-600">{user?.userType === "doctor" ? "Healthcare Provider" : "Patient"}</p>
              </div>
            </div>

            <div className="mt-8 flex gap-3 justify-center flex-wrap">
              <button
                onClick={() => navigate("/settings")}
                className="px-6 py-2.5 bg-blue-600 text-white font-bold rounded-lg hover:bg-blue-700 transition"
              >
                Go to Settings
              </button>
              <button
                onClick={() => navigate("/medical-records")}
                className="px-6 py-2.5 bg-emerald-600 text-white font-bold rounded-lg hover:bg-emerald-700 transition"
              >
                Medical Records
              </button>
              <button
                onClick={() => logout()}
                className="px-6 py-2.5 bg-red-600 text-white font-bold rounded-lg hover:bg-red-700 transition"
              >
                Logout
              </button>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
