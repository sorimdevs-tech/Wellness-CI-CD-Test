import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useUser } from "../context/UserContext";

export default function Login() {
  const [mobile, setMobile] = useState("");
  const [otp, setOtp] = useState("");
  const [otpSent, setOtpSent] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const navigate = useNavigate();
  const { setUser, createSession } = useUser();

  const generateOtp = () => {
    setError("");

    if (!mobile.trim()) {
      setError("Please enter your mobile number or username");
      return;
    }

    if (!/^\d{10}$|^[a-zA-Z0-9_]{3,}$/.test(mobile)) {
      setError("Enter a valid 10-digit number or username");
      return;
    }

    setLoading(true);

    setTimeout(() => {
      setOtpSent(true);
      setLoading(false);

      setTimeout(() => {
        setOtp("123456");
      }, 900);
    }, 1200);
  };

  const handleLogin = () => {
    setError("");

    if (!otp.trim()) {
      setError("Please enter the OTP");
      return;
    }

    if (otp === "123456") {
      setLoading(true);

      // Check if it's a predefined user or doctor
      const isDoctor = mobile === "9876543211";
      const isUser = mobile === "9876543210";

      setTimeout(() => {
        let userData;
        
        if (isDoctor) {
          // Doctor login
          localStorage.setItem("userType", "doctor");
          localStorage.setItem("userMobile", mobile);
          localStorage.setItem("currentRole", "doctor");
          
          userData = {
            id: "doc_001",
            name: "Dr. Rajesh Kumar",
            mobile,
            userType: "doctor" as const,
            currentRole: "doctor" as const,
            regNumber: "MED2024001",
          };
        } else if (isUser) {
          // Regular user login
          localStorage.setItem("userType", "user");
          localStorage.setItem("userMobile", mobile);
          localStorage.setItem("currentRole", "user");
          
          userData = {
            id: "user_001",
            name: "Amit Kumar",
            mobile,
            userType: "user" as const,
            currentRole: "user" as const,
          };
        } else {
          // Default user login for other numbers
          localStorage.setItem("userType", "user");
          localStorage.setItem("userMobile", mobile);
          localStorage.setItem("currentRole", "user");
          
          userData = {
            id: `user_${Date.now()}`,
            name: `User ${mobile}`,
            mobile,
            userType: "user" as const,
            currentRole: "user" as const,
          };
        }
        
        setUser(userData);
        createSession(userData);
        navigate("/dashboard");
      }, 800);
    } else {
      setError("Incorrect OTP. Try again.");
    }
  };

  const handleReset = () => {
    setMobile("");
    setOtp("");
    setOtpSent(false);
    setError("");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-emerald-50 flex items-center justify-center p-6">
      {/* GLASS CARD CONTAINER */}
      <div className="max-w-md w-full backdrop-blur-xl bg-white/60 shadow-xl rounded-3xl border border-white/40 p-10">
        
        {/* BRANDING */}
        <div className="flex flex-col items-center mb-10">
          <div className="w-20 h-20 rounded-full bg-gradient-to-br from-blue-600 to-emerald-500 shadow-lg flex items-center justify-center">
            <svg className="w-10 h-10 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeWidth={2} d="M12 6v12m6-6H6" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>

          <h1 className="mt-4 text-4xl font-extrabold bg-gradient-to-r from-blue-700 to-emerald-600 text-transparent bg-clip-text tracking-tight">
            Wellness Dev
          </h1>
          <p className="text-gray-600 mt-1">
            By Sorim AI
          </p>
        </div>

        {/* ERROR MESSAGE */}
        {error && (
          <div className="mb-6 p-4 bg-red-100 border border-red-300 rounded-xl text-sm text-red-700 flex gap-2 items-start">
            <svg className="w-5 h-5 shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
              <path d="M10 18a8 8 0 100-16 8 8 0 000 16zm-1-11h2v5h-2V7zm0 6h2v2h-2v-2z"/>
            </svg>
            {error}
          </div>
        )}

        {/* STEP 1 — ENTER MOBILE */}
        {!otpSent ? (
          <div className="space-y-6">
            <div>
              <label className="font-medium text-gray-700 text-sm mb-2 block">Mobile Number / Username</label>
              <div className="relative">
                <input
                  type="text"
                  value={mobile}
                  onChange={(e) => setMobile(e.target.value)}
                  placeholder="Enter mobile or username"
                  className="w-full py-3 pl-12 pr-4 rounded-xl border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent placeholder-gray-400"
                />
                <svg className="absolute w-5 h-5 left-4 top-3.5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" d="M3 8l9 6 9-6"/>
                </svg>
              </div>
              <div className="mt-3 p-3 bg-blue-50 rounded-lg border border-blue-200 text-xs text-gray-700">
                <p className="font-semibold text-blue-700 mb-1">Test Accounts:</p>
                <p>👤 User: <code className="bg-white px-2 py-1 rounded font-mono">9876543210</code></p>
                <p>👨‍⚕️ Doctor: <code className="bg-white px-2 py-1 rounded font-mono">9876543211</code></p>
                <p className="mt-1 text-gray-600">OTP: <code className="bg-white px-2 py-1 rounded font-mono">123456</code></p>
              </div>
            </div>

            <button
              onClick={generateOtp}
              disabled={loading}
              className="w-full py-3 bg-gradient-to-r from-blue-600 to-blue-700 hover:opacity-90 text-white font-semibold rounded-xl shadow-md flex items-center justify-center transition"
            >
              {loading ? (
                <div className="flex items-center gap-2">
                  <div className="animate-spin w-5 h-5 border-2 border-white border-t-transparent rounded-full"></div>
                  Sending OTP...
                </div>
              ) : (
                "Send OTP"
              )}
            </button>
          </div>
        ) : (
          /* STEP 2 — ENTER OTP */
          <div className="space-y-6">            <div className="bg-green-50 border border-green-300 px-4 py-3 rounded-xl text-green-700 text-sm flex gap-2">
              <svg className="w-5 h-5 mt-0.5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                <path d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.7-9.3a1 1 0 10-1.4-1.4L9 10.6 7.7 9.3a1 1 0 10-1.4 1.4l2 2a1 1 0 001.4 0l4-4z"/>
              </svg>
              OTP sent to <strong>{mobile}</strong>
            </div>

            <div>
              <label className="font-medium text-gray-700 text-sm mb-2 block">Enter OTP</label>
              <div className="relative">
                <input
                  type="text"
                  maxLength={6}
                  value={otp}
                  onChange={(e) => setOtp(e.target.value)}
                  placeholder="______"
                  className="w-full py-3 text-center tracking-widest text-2xl border border-gray-300 rounded-xl focus:ring-2 focus:ring-green-500"
                />
              </div>
            </div>

            <button
              onClick={handleLogin}
              disabled={loading}
              className="w-full py-3 bg-gradient-to-r from-emerald-600 to-emerald-700 hover:opacity-90 text-white font-semibold rounded-xl shadow-md flex items-center justify-center transition"
            >
              {loading ? (
                <div className="flex items-center gap-2">
                  <div className="animate-spin w-5 h-5 border-2 border-white border-t-transparent rounded-full"></div>
                  Verifying...
                </div>
              ) : (
                "Verify & Login"
              )}
            </button>

            <button
              onClick={handleReset}
              className="w-full py-2 text-blue-600 hover:text-blue-700 hover:bg-blue-50 rounded-xl transition font-medium"
            >
              ← Edit Mobile Number
            </button>

            <p className="text-center text-xs text-gray-600">
              Didn’t receive code?{" "}
              <span className="text-blue-600 font-medium hover:underline cursor-pointer">Resend OTP</span>
            </p>
          </div>
        )}

        {/* FOOTER */}
        <p className="mt-8 text-center text-xs text-gray-500">
          Secured by AES Encryption • HIPAA Compliant
        </p>

        {/* CREATE ACCOUNT LINK */}
        <div className="mt-6 pt-6 border-t border-gray-200">
          <p className="text-center text-sm text-gray-600">
            Don't have an account?{" "}
            <button
              onClick={() => navigate("/register")}
              className="text-blue-600 hover:text-blue-700 font-semibold hover:underline transition"
            >
              Create Account
            </button>
          </p>
        </div>

        {/* FOOTER - SORIM TECHNOLOGY */}
        <div className="mt-8 pt-6 border-t border-gray-200 text-center">
          <p className="text-xs text-gray-500">
            Developed by <span className="font-semibold text-gray-700">Sorim Technology</span>
          </p>
          <p className="text-xs text-gray-400 mt-1">© 2025 Wellness Dev. All rights reserved.</p>
        </div>
      </div>
    </div>
  );
}
