import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useUser } from "../context/UserContext";
import { useAppointment } from "../context/AppointmentContext";
import NotificationsPanel from "../components/NotificationsPanel";

export default function DoctorDashboard() {
  const navigate = useNavigate();
  const { user, switchRole, logout } = useUser();
  const { appointments, confirmAppointment, cancelAppointment, getNotifications } =
    useAppointment();
  const [activeTab, setActiveTab] = useState("dashboard");
  const [showNotifications, setShowNotifications] = useState(false);

  const doctorAppointments = appointments.filter(
    (apt) => apt.doctorId === user?.id
  );
  const pendingAppointments = doctorAppointments.filter(
    (apt) => apt.status === "pending"
  );
  const confirmedAppointments = doctorAppointments.filter(
    (apt) => apt.status === "confirmed"
  );

  const doctorNotifications = user ? getNotifications(user.id || "", "doctor") : [];
  const unreadCount = doctorNotifications.filter((n) => !n.read).length;

  const upcomingAppointments = [
    {
      id: 1,
      patientName: "Huisain Li",
      patientId: "391167538",
      doctor: "Served by Erica Lim",
      medicines: ["Loperamide 2mg (10 tabs)", "Telfaxe 180mg (20 tabs)"],
      price: "$37.05",
      status: "Not Paid",
    },
    {
      id: 2,
      patientName: "Joe White",
      patientId: "391158917",
      doctor: "Served by Erica Lim",
      medicines: ["Loperamide 2mg (10 tabs)", "Telfaxe 180mg (20 tabs)"],
      price: "$34.05",
      status: "Paid",
    },
  ];

  const scheduleAppointments = [
    {
      id: 1,
      date: "23 Nov, 12:30 PM",
      time: "30 Minutes",
      specialty: "Dentist",
      doctorName: "Dr. Priscilla",
    },
  ];

  const patients = [
    { id: 1, name: "Dr. Naresh Kumar", specialty: "Cardiologist", date: "5 Nov 2024" },
    { id: 2, name: "Dr. Jane Cooper", specialty: "Pediatrician", date: "2 Nov 2024" },
    { id: 3, name: "Dr. Jenny Wilson", specialty: "General", date: "13 Oct 2024" },
    { id: 4, name: "Dr. Devon Lane", specialty: "Neurologist", date: "11 Aug 2024" },
  ];

  const doctors = [
    { id: 1, name: "Dr. Sarah Jones", specialty: "Neurology", phone: "(555) 1234" },
    { id: 2, name: "Dr. John Smith", specialty: "Cardiology", phone: "(555) 2345" },
    { id: 3, name: "Dr. Emily Brown", specialty: "Orthopedics", phone: "(535) 3458" },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* HEADER */}
      <div className="bg-white border-b border-gray-200 px-8 py-6">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-emerald-500 rounded-lg flex items-center justify-center">
              <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" d="M12 6v12m6-6H6" />
              </svg>
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Wellness Dev</h1>
              <p className="text-xs text-gray-500 mt-0.5">Doctor Management Panel - By Sorim AI</p>
            </div>
          </div>
          <div className="flex items-center gap-6">
            <button
              onClick={() => setShowNotifications(true)}
              className="text-gray-600 hover:text-gray-900 relative"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
              </svg>
              {unreadCount > 0 && (
                <span className="absolute top-0 right-0 w-5 h-5 bg-red-500 text-white text-xs font-bold rounded-full flex items-center justify-center">
                  {unreadCount}
                </span>
              )}
            </button>

            {/* ROLE SWITCHER */}
            <div className="flex items-center gap-2 bg-gray-100 px-3 py-2 rounded-lg">
              <button
                onClick={() => switchRole("user")}
                className={`px-3 py-1 rounded-lg font-semibold transition ${
                  user?.currentRole === "user"
                    ? "bg-blue-600 text-white"
                    : "text-gray-600 hover:text-gray-900"
                }`}
              >
                User
              </button>
              <button
                onClick={() => switchRole("doctor")}
                className={`px-3 py-1 rounded-lg font-semibold transition ${
                  user?.currentRole === "doctor"
                    ? "bg-blue-600 text-white"
                    : "text-gray-600 hover:text-gray-900"
                }`}
              >
                Doctor
              </button>
            </div>

            <button
              onClick={() => logout()}
              className="text-gray-600 hover:text-red-600 transition"
              title="Logout"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
              </svg>
            </button>

            <button className="w-10 h-10 rounded-full bg-gray-300 flex items-center justify-center">
              <span className="text-sm font-bold text-gray-900">DR</span>
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-8">
        {/* TABS */}
        <div className="flex gap-2 mb-8 bg-white p-2 rounded-lg w-fit">
          {[
            { id: "dashboard", label: "Dashboard" },
            { id: "appointments", label: "Appointments", badge: pendingAppointments.length },
            { id: "statistics", label: "Statistics" },
            { id: "schedule", label: "Schedule" },
            { id: "doctors", label: "Doctors" },
            { id: "settings", label: "Settings" },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-4 py-2 rounded-lg font-medium transition relative ${
                activeTab === tab.id
                  ? "bg-blue-100 text-blue-700"
                  : "text-gray-600 hover:text-gray-900"
              }`}
            >
              {tab.label}
              {"badge" in tab && (tab.badge as number) > 0 && (
                <span className="absolute top-0 right-0 w-5 h-5 bg-red-500 text-white text-xs font-bold rounded-full flex items-center justify-center -mt-2 -mr-2">
                  {tab.badge}
                </span>
              )}
            </button>
          ))}
        </div>        {activeTab === "dashboard" && (
          <>
            {/* WELCOME SECTION */}
            <div className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Hello, Tyra</h2>
              <p className="text-gray-600">You have 1 appointment today</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* LEFT SECTION */}
              <div className="lg:col-span-2 space-y-8">
                {/* QUICK STATS */}
                <div className="grid grid-cols-3 gap-4">
                  <div className="bg-white p-6 rounded-lg shadow">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-gray-600 text-sm mb-1">Heart Rate</p>
                        <p className="text-3xl font-bold text-gray-900">120</p>
                        <p className="text-gray-500 text-xs mt-1">BPM</p>
                      </div>
                      <svg className="w-12 h-12 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                      </svg>
                    </div>
                  </div>

                  <div className="bg-white p-6 rounded-lg shadow">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-gray-600 text-sm mb-1">Blood Cell</p>
                        <p className="text-3xl font-bold text-gray-900">9,800</p>
                        <p className="text-gray-500 text-xs mt-1">uL</p>
                      </div>
                      <svg className="w-12 h-12 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                      </svg>
                    </div>
                  </div>

                  <div className="bg-white p-6 rounded-lg shadow">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-gray-600 text-sm mb-1">Water</p>
                        <p className="text-3xl font-bold text-gray-900">89%</p>
                        <p className="text-gray-500 text-xs mt-1">1.78/2 Litres</p>
                      </div>
                      <svg className="w-12 h-12 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                      </svg>
                    </div>
                  </div>
                </div>

                {/* REAL-TIME CHAT */}
                <div className="bg-white p-6 rounded-lg shadow">
                  <h3 className="text-lg font-bold text-gray-900 mb-4">Real-Time Chat</h3>
                  <div className="mb-6 p-4 bg-blue-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-emerald-500 rounded-full"></div>
                      <p className="text-gray-800">I'm available for a video consultation.</p>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="Type a message..."
                      className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                    <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
                      <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5.951-1.429 5.951 1.429a1 1 0 001.169-1.409l-7-14z" />
                      </svg>
                    </button>
                  </div>
                </div>

                {/* QUICK ACTIONS */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-gradient-to-br from-red-100 to-red-50 p-6 rounded-lg text-center cursor-pointer hover:shadow-lg transition">
                    <div className="w-12 h-12 bg-red-500 rounded-full flex items-center justify-center mx-auto mb-2">
                      <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" d="M12 8v4m0 4v.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                    </div>
                    <p className="font-bold text-gray-900">Emergency Assistance</p>
                  </div>

                  <div className="bg-gradient-to-br from-blue-100 to-blue-50 p-6 rounded-lg text-center cursor-pointer hover:shadow-lg transition">
                    <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-2">
                      <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                      </svg>
                    </div>
                    <p className="font-bold text-gray-900">Personal Vault</p>
                  </div>

                  <div className="bg-gradient-to-br from-amber-100 to-amber-50 p-6 rounded-lg text-center cursor-pointer hover:shadow-lg transition">
                    <div className="w-12 h-12 bg-amber-500 rounded-full flex items-center justify-center mx-auto mb-2">
                      <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" />
                      </svg>
                    </div>
                    <p className="font-bold text-gray-900">Patient Directory</p>
                  </div>

                  <div className="bg-gradient-to-br from-purple-100 to-purple-50 p-6 rounded-lg text-center cursor-pointer hover:shadow-lg transition">
                    <div className="w-12 h-12 bg-purple-500 rounded-full flex items-center justify-center mx-auto mb-2">
                      <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.5a2 2 0 00-1 .267M7 21H5a2 2 0 01-2-2v-4a2 2 0 012-2h2.5" />
                      </svg>
                    </div>
                    <p className="font-bold text-gray-900">Prescription Manager</p>
                  </div>
                </div>
              </div>

              {/* RIGHT SECTION */}
              <div className="space-y-6">
                {/* UPCOMING APPOINTMENT */}
                <div className="bg-gradient-to-br from-yellow-100 to-yellow-50 p-6 rounded-lg">
                  <h3 className="text-lg font-bold text-gray-900 mb-4">Upcoming Appointment</h3>
                  <div className="bg-white rounded-lg p-4 mb-4">
                    <div className="flex items-start gap-4 mb-4">
                      <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-emerald-500 rounded-full"></div>
                      <div>
                        <p className="font-bold text-gray-900">Dr. Priscilla</p>
                        <p className="text-xs text-gray-600 bg-yellow-200 px-2 py-1 rounded mt-1 w-fit">Dentist</p>
                      </div>
                    </div>
                    <p className="text-sm text-gray-600 mb-3">Dr. Priscilla is a skilled dentist dedicated to providing top-quality dental care with a focus on patient comfort and satisfaction.</p>
                    <div className="space-y-2 text-sm text-gray-600 mb-4">
                      <div className="flex items-center gap-2">
                        <svg className="w-4 h-4 text-blue-600" fill="currentColor" viewBox="0 0 20 20">
                          <path d="M5.5 13a3.5 3.5 0 01-.369-6.98 4 4 0 117.753-1.3A4.5 4.5 0 1113.5 13H11V9.413l1.293 1.293a1 1 0 001.414-1.414l-3-3a1 1 0 00-1.414 0l-3 3a1 1 0 001.414 1.414L9 9.414V13H5.5z" />
                        </svg>
                        23 Nov, 12:30 PM
                      </div>
                      <div className="flex items-center gap-2">
                        <svg className="w-4 h-4 text-green-600" fill="currentColor" viewBox="0 0 20 20">
                          <path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5.951-1.429 5.951 1.429a1 1 0 001.169-1.409l-7-14z" />
                        </svg>
                        30 Minutes
                      </div>
                    </div>
                    <button className="w-full bg-gray-900 text-white py-2 rounded-lg font-semibold hover:bg-gray-800">
                      Check Appointments
                    </button>
                  </div>
                </div>

                {/* LATEST APPOINTMENTS */}
                <div className="bg-white p-6 rounded-lg shadow">
                  <h3 className="text-lg font-bold text-gray-900 mb-4">Latest Appointments</h3>
                  <p className="text-sm text-gray-600 mb-4">Stay updated on your last healthcare visit.</p>
                  <div className="space-y-3">
                    {patients.map((patient) => (
                      <div key={patient.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 cursor-pointer">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-emerald-500 rounded-full"></div>
                          <div>
                            <p className="text-sm font-semibold text-gray-900">{patient.name}</p>
                            <p className="text-xs text-gray-600">{patient.date}</p>
                          </div>
                        </div>
                        <svg className="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
                        </svg>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </>
        )}

        {/* APPOINTMENTS TAB */}
        {activeTab === "appointments" && (
          <div className="space-y-6">
            {/* PENDING APPOINTMENTS */}
            <div className="bg-white rounded-lg shadow overflow-hidden">
              <div className="bg-orange-50 border-b border-orange-200 px-6 py-4">
                <h3 className="text-lg font-bold text-gray-900">
                  Pending Appointments ({pendingAppointments.length})
                </h3>
                <p className="text-sm text-gray-600 mt-1">
                  Review and confirm appointment requests from patients
                </p>
              </div>
              {pendingAppointments.length === 0 ? (
                <div className="p-8 text-center text-gray-600">
                  <svg className="w-16 h-16 text-gray-300 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" d="M8 7V3m8 4V3m-9 8h18M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                  </svg>
                  <p>No pending appointments</p>
                </div>
              ) : (
                <div className="divide-y">
                  {pendingAppointments.map((apt) => (
                    <div key={apt.id} className="p-6 hover:bg-gray-50 transition">
                      <div className="flex items-start justify-between mb-4">
                        <div>
                          <h4 className="font-bold text-gray-900">{apt.userName}</h4>
                          <p className="text-sm text-gray-600 mt-1">
                            📅 {apt.date} at {apt.time}
                          </p>
                        </div>
                        <span className="px-3 py-1 bg-orange-100 text-orange-700 rounded-full text-xs font-semibold">
                          Pending
                        </span>
                      </div>
                      <div className="bg-gray-50 p-4 rounded-lg mb-4">
                        <p className="text-sm text-gray-700">
                          <span className="font-semibold">Reason:</span> {apt.reason}
                        </p>
                      </div>
                      <div className="flex gap-3">
                        <button
                          onClick={() => confirmAppointment(apt.id)}
                          className="flex-1 px-4 py-2 bg-green-600 text-white font-semibold rounded-lg hover:bg-green-700 transition"
                        >
                          ✓ Confirm
                        </button>
                        <button
                          onClick={() => cancelAppointment(apt.id)}
                          className="flex-1 px-4 py-2 bg-red-600 text-white font-semibold rounded-lg hover:bg-red-700 transition"
                        >
                          ✕ Decline
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* CONFIRMED APPOINTMENTS */}
            <div className="bg-white rounded-lg shadow overflow-hidden">
              <div className="bg-green-50 border-b border-green-200 px-6 py-4">
                <h3 className="text-lg font-bold text-gray-900">
                  Confirmed Appointments ({confirmedAppointments.length})
                </h3>
              </div>
              {confirmedAppointments.length === 0 ? (
                <div className="p-8 text-center text-gray-600">
                  <p>No confirmed appointments yet</p>
                </div>
              ) : (
                <div className="divide-y">
                  {confirmedAppointments.map((apt) => (
                    <div key={apt.id} className="p-6 hover:bg-gray-50 transition">
                      <div className="flex items-start justify-between">
                        <div>
                          <h4 className="font-bold text-gray-900">{apt.userName}</h4>
                          <p className="text-sm text-gray-600 mt-1">
                            📅 {apt.date} at {apt.time}
                          </p>
                          <p className="text-sm text-gray-700 mt-2">
                            <span className="font-semibold">Reason:</span> {apt.reason}
                          </p>
                        </div>
                        <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-xs font-semibold">
                          Confirmed
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* OTHER TABS PLACEHOLDERS */}
        {activeTab !== "dashboard" && activeTab !== "appointments" && (
          <div className="bg-white p-8 rounded-lg shadow text-center">
            <p className="text-gray-600 text-lg">{activeTab.charAt(0).toUpperCase() + activeTab.slice(1)} section coming soon...</p>
          </div>
        )}
      </div>

      {/* NOTIFICATIONS PANEL */}
      {user && (
        <NotificationsPanel
          isOpen={showNotifications}
          onClose={() => setShowNotifications(false)}
          userId={user.id || ""}
          userType="doctor"
        />
      )}
    </div>
  );
}
