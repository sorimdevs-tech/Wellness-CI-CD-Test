import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useUser } from "../context/UserContext";
import Header from "../components/Header";
import Footer from "../components/Footer";

export default function SettingsPage() {
  const navigate = useNavigate();
  const { user, logout } = useUser();
  const [settingsData, setSettingsData] = useState({
    notifications: {
      emailNotifications: true,
      pushNotifications: true,
      appointmentReminders: true,
      healthTips: false,
      promosAndOffers: false,
    },
    privacy: {
      profileVisibility: "private",
      shareHealthData: false,
      allowResearch: false,
    },
    preferences: {
      language: "English",
      theme: "light",
      dateFormat: "DD/MM/YYYY",
      distanceUnit: "km",
    },
  });

  const [showSuccessMessage, setShowSuccessMessage] = useState(false);
  const [activeTab, setActiveTab] = useState("notifications");

  const handleToggle = (category: keyof typeof settingsData, key: string) => {
    const categoryData = settingsData[category];
    setSettingsData({
      ...settingsData,
      [category]: {
        ...categoryData,
        [key]: !categoryData[key as keyof typeof categoryData],
      },
    });
  };

  const handleSelectChange = (category: keyof typeof settingsData, key: string, value: string) => {
    const categoryData = settingsData[category];
    setSettingsData({
      ...settingsData,
      [category]: {
        ...categoryData,
        [key]: value,
      },
    });
  };

  const handleSaveSettings = () => {
    setShowSuccessMessage(true);
    setTimeout(() => setShowSuccessMessage(false), 3000);
  };

  return (
    <div className="min-h-screen bg-white flex flex-col">
      <Header />

      <div className="max-w-5xl mx-auto px-4 md:px-8 lg:px-12 py-12 flex-1 w-full">
        {/* PAGE TITLE */}
        <div className="mb-10">
          <h1 className="text-4xl font-bold text-gray-900">Settings</h1>
          <p className="text-gray-600 mt-2">Customize your experience and manage preferences</p>
        </div>

        {/* SETTINGS CONTAINER */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* SIDEBAR - TABS */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-2xl shadow-lg border border-gray-200 p-4 sticky top-24">
              <nav className="space-y-2">
                <button
                  onClick={() => setActiveTab("notifications")}
                  className={`w-full text-left px-4 py-3 rounded-lg font-semibold transition flex items-center gap-3 ${
                    activeTab === "notifications"
                      ? "bg-blue-600 text-white"
                      : "text-gray-700 hover:bg-gray-100"
                  }`}
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                  </svg>
                  Notifications
                </button>

                <button
                  onClick={() => setActiveTab("privacy")}
                  className={`w-full text-left px-4 py-3 rounded-lg font-semibold transition flex items-center gap-3 ${
                    activeTab === "privacy"
                      ? "bg-blue-600 text-white"
                      : "text-gray-700 hover:bg-gray-100"
                  }`}
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                  </svg>
                  Privacy & Security
                </button>

                <button
                  onClick={() => setActiveTab("preferences")}
                  className={`w-full text-left px-4 py-3 rounded-lg font-semibold transition flex items-center gap-3 ${
                    activeTab === "preferences"
                      ? "bg-blue-600 text-white"
                      : "text-gray-700 hover:bg-gray-100"
                  }`}
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                  </svg>
                  Preferences
                </button>

                <button
                  onClick={() => setActiveTab("account")}
                  className={`w-full text-left px-4 py-3 rounded-lg font-semibold transition flex items-center gap-3 ${
                    activeTab === "account"
                      ? "bg-blue-600 text-white"
                      : "text-gray-700 hover:bg-gray-100"
                  }`}
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" d="M10 6H5a2 2 0 00-2 2v10a2 2 0 002 2h5m0 0h5a2 2 0 002-2m0 0V6a2 2 0 00-2-2h-5m0 0V5a2 2 0 00-2-2h-.5A2.5 2.5 0 003 7.5V9m0 0h18" />
                  </svg>
                  Account
                </button>
              </nav>
            </div>
          </div>

          {/* MAIN CONTENT */}
          <div className="lg:col-span-3">
            {/* NOTIFICATIONS TAB */}
            {activeTab === "notifications" && (
              <div className="bg-white rounded-3xl shadow-xl border border-gray-200 p-10">
                <h2 className="text-2xl font-bold text-gray-900 mb-8">Notification Preferences</h2>

                <div className="space-y-6">
                  <div className="flex items-center justify-between p-5 bg-gray-50 rounded-xl border border-gray-200 hover:border-blue-300 transition">
                    <div>
                      <h4 className="font-bold text-gray-900">Email Notifications</h4>
                      <p className="text-sm text-gray-600">Receive important updates via email</p>
                    </div>
                    <button
                      onClick={() => handleToggle("notifications", "emailNotifications")}
                      className={`relative inline-flex h-8 w-14 items-center rounded-full transition ${
                        settingsData.notifications.emailNotifications ? "bg-blue-600" : "bg-gray-300"
                      }`}
                    >
                      <span
                        className={`inline-block h-6 w-6 transform rounded-full bg-white transition ${
                          settingsData.notifications.emailNotifications ? "translate-x-7" : "translate-x-1"
                        }`}
                      />
                    </button>
                  </div>

                  <div className="flex items-center justify-between p-5 bg-gray-50 rounded-xl border border-gray-200 hover:border-blue-300 transition">
                    <div>
                      <h4 className="font-bold text-gray-900">Push Notifications</h4>
                      <p className="text-sm text-gray-600">Get real-time alerts on your device</p>
                    </div>
                    <button
                      onClick={() => handleToggle("notifications", "pushNotifications")}
                      className={`relative inline-flex h-8 w-14 items-center rounded-full transition ${
                        settingsData.notifications.pushNotifications ? "bg-blue-600" : "bg-gray-300"
                      }`}
                    >
                      <span
                        className={`inline-block h-6 w-6 transform rounded-full bg-white transition ${
                          settingsData.notifications.pushNotifications ? "translate-x-7" : "translate-x-1"
                        }`}
                      />
                    </button>
                  </div>

                  <div className="flex items-center justify-between p-5 bg-gray-50 rounded-xl border border-gray-200 hover:border-blue-300 transition">
                    <div>
                      <h4 className="font-bold text-gray-900">Appointment Reminders</h4>
                      <p className="text-sm text-gray-600">Reminders before your scheduled appointments</p>
                    </div>
                    <button
                      onClick={() => handleToggle("notifications", "appointmentReminders")}
                      className={`relative inline-flex h-8 w-14 items-center rounded-full transition ${
                        settingsData.notifications.appointmentReminders ? "bg-blue-600" : "bg-gray-300"
                      }`}
                    >
                      <span
                        className={`inline-block h-6 w-6 transform rounded-full bg-white transition ${
                          settingsData.notifications.appointmentReminders ? "translate-x-7" : "translate-x-1"
                        }`}
                      />
                    </button>
                  </div>

                  <div className="flex items-center justify-between p-5 bg-gray-50 rounded-xl border border-gray-200 hover:border-blue-300 transition">
                    <div>
                      <h4 className="font-bold text-gray-900">Health Tips</h4>
                      <p className="text-sm text-gray-600">Receive personalized health tips and advice</p>
                    </div>
                    <button
                      onClick={() => handleToggle("notifications", "healthTips")}
                      className={`relative inline-flex h-8 w-14 items-center rounded-full transition ${
                        settingsData.notifications.healthTips ? "bg-blue-600" : "bg-gray-300"
                      }`}
                    >
                      <span
                        className={`inline-block h-6 w-6 transform rounded-full bg-white transition ${
                          settingsData.notifications.healthTips ? "translate-x-7" : "translate-x-1"
                        }`}
                      />
                    </button>
                  </div>

                  <div className="flex items-center justify-between p-5 bg-gray-50 rounded-xl border border-gray-200 hover:border-blue-300 transition">
                    <div>
                      <h4 className="font-bold text-gray-900">Promos and Offers</h4>
                      <p className="text-sm text-gray-600">Special promotions and exclusive offers</p>
                    </div>
                    <button
                      onClick={() => handleToggle("notifications", "promosAndOffers")}
                      className={`relative inline-flex h-8 w-14 items-center rounded-full transition ${
                        settingsData.notifications.promosAndOffers ? "bg-blue-600" : "bg-gray-300"
                      }`}
                    >
                      <span
                        className={`inline-block h-6 w-6 transform rounded-full bg-white transition ${
                          settingsData.notifications.promosAndOffers ? "translate-x-7" : "translate-x-1"
                        }`}
                      />
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* PRIVACY TAB */}
            {activeTab === "privacy" && (
              <div className="bg-white rounded-3xl shadow-xl border border-gray-200 p-10">
                <h2 className="text-2xl font-bold text-gray-900 mb-8">Privacy & Security</h2>

                <div className="space-y-8">
                  <div>
                    <label className="block text-sm font-bold text-gray-900 mb-4">Profile Visibility</label>
                    <div className="space-y-3">
                      {["private", "friends", "public"].map((option) => (
                        <label key={option} className="flex items-center p-4 border-2 border-gray-200 rounded-xl cursor-pointer hover:border-blue-300 transition">
                          <input
                            type="radio"
                            name="profileVisibility"
                            value={option}
                            checked={settingsData.privacy.profileVisibility === option}
                            onChange={(e) => handleSelectChange("privacy", "profileVisibility", e.target.value)}
                            className="w-4 h-4 text-blue-600"
                          />
                          <span className="ml-3 font-semibold text-gray-900 capitalize">{option}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  <div className="border-t-2 border-gray-200 pt-8">
                    <div className="flex items-center justify-between p-5 bg-gray-50 rounded-xl border border-gray-200 hover:border-blue-300 transition">
                      <div>
                        <h4 className="font-bold text-gray-900">Share Health Data</h4>
                        <p className="text-sm text-gray-600">Allow doctors to access your health records</p>
                      </div>
                      <button
                        onClick={() => handleToggle("privacy", "shareHealthData")}
                        className={`relative inline-flex h-8 w-14 items-center rounded-full transition ${
                          settingsData.privacy.shareHealthData ? "bg-blue-600" : "bg-gray-300"
                        }`}
                      >
                        <span
                          className={`inline-block h-6 w-6 transform rounded-full bg-white transition ${
                            settingsData.privacy.shareHealthData ? "translate-x-7" : "translate-x-1"
                          }`}
                        />
                      </button>
                    </div>
                  </div>

                  <div className="border-t-2 border-gray-200 pt-8">
                    <div className="flex items-center justify-between p-5 bg-gray-50 rounded-xl border border-gray-200 hover:border-blue-300 transition">
                      <div>
                        <h4 className="font-bold text-gray-900">Allow Research</h4>
                        <p className="text-sm text-gray-600">Participate in health research programs</p>
                      </div>
                      <button
                        onClick={() => handleToggle("privacy", "allowResearch")}
                        className={`relative inline-flex h-8 w-14 items-center rounded-full transition ${
                          settingsData.privacy.allowResearch ? "bg-blue-600" : "bg-gray-300"
                        }`}
                      >
                        <span
                          className={`inline-block h-6 w-6 transform rounded-full bg-white transition ${
                            settingsData.privacy.allowResearch ? "translate-x-7" : "translate-x-1"
                          }`}
                        />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* PREFERENCES TAB */}
            {activeTab === "preferences" && (
              <div className="bg-white rounded-3xl shadow-xl border border-gray-200 p-10">
                <h2 className="text-2xl font-bold text-gray-900 mb-8">General Preferences</h2>

                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-bold text-gray-900 mb-3">Language</label>
                    <select
                      value={settingsData.preferences.language}
                      onChange={(e) => handleSelectChange("preferences", "language", e.target.value)}
                      className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none transition bg-white"
                    >
                      <option>English</option>
                      <option>Tamil</option>
                      <option>Hindi</option>
                      <option>Telugu</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-bold text-gray-900 mb-3">Theme</label>
                    <select
                      value={settingsData.preferences.theme}
                      onChange={(e) => handleSelectChange("preferences", "theme", e.target.value)}
                      className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none transition bg-white"
                    >
                      <option value="light">Light</option>
                      <option value="dark">Dark</option>
                      <option value="auto">Auto</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-bold text-gray-900 mb-3">Date Format</label>
                    <select
                      value={settingsData.preferences.dateFormat}
                      onChange={(e) => handleSelectChange("preferences", "dateFormat", e.target.value)}
                      className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none transition bg-white"
                    >
                      <option>DD/MM/YYYY</option>
                      <option>MM/DD/YYYY</option>
                      <option>YYYY-MM-DD</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-bold text-gray-900 mb-3">Distance Unit</label>
                    <select
                      value={settingsData.preferences.distanceUnit}
                      onChange={(e) => handleSelectChange("preferences", "distanceUnit", e.target.value)}
                      className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none transition bg-white"
                    >
                      <option value="km">Kilometers (km)</option>
                      <option value="miles">Miles</option>
                    </select>
                  </div>
                </div>
              </div>
            )}

            {/* ACCOUNT TAB */}
            {activeTab === "account" && (
              <div className="bg-white rounded-3xl shadow-xl border border-gray-200 p-10">
                <h2 className="text-2xl font-bold text-gray-900 mb-8">Account Settings</h2>

                <div className="space-y-6">
                  <div className="p-6 bg-blue-50 rounded-xl border border-blue-200">
                    <h4 className="font-bold text-gray-900 mb-2">Account Information</h4>
                    <p className="text-sm text-gray-700 mb-4">Email: {user?.email}</p>
                    <button className="px-4 py-2 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 transition">
                      Change Password
                    </button>
                  </div>

                  <div className="p-6 bg-orange-50 rounded-xl border border-orange-200">
                    <h4 className="font-bold text-gray-900 mb-2">Two-Factor Authentication</h4>
                    <p className="text-sm text-gray-700 mb-4">Add an extra layer of security to your account</p>
                    <button className="px-4 py-2 bg-orange-600 text-white font-semibold rounded-lg hover:bg-orange-700 transition">
                      Enable 2FA
                    </button>
                  </div>

                  <div className="p-6 bg-red-50 rounded-xl border border-red-200">
                    <h4 className="font-bold text-gray-900 mb-2">Delete Account</h4>
                    <p className="text-sm text-gray-700 mb-4">Permanently delete your account and all associated data</p>
                    <button className="px-4 py-2 bg-red-600 text-white font-semibold rounded-lg hover:bg-red-700 transition">
                      Delete Account
                    </button>
                  </div>

                  <div className="pt-6 border-t-2 border-gray-200">
                    <button
                      onClick={() => logout()}
                      className="w-full px-6 py-3 bg-gray-200 text-gray-900 font-bold rounded-lg hover:bg-gray-300 transition flex items-center justify-center gap-2"
                    >
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                      </svg>
                      Logout
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* SAVE BUTTON */}
            <div className="mt-8 flex items-center gap-4">
              <button
                onClick={handleSaveSettings}
                className="px-8 py-3 bg-blue-600 text-white font-bold rounded-lg hover:bg-blue-700 transition shadow-lg flex items-center gap-2"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                </svg>
                Save Settings
              </button>
              <button
                onClick={() => navigate("/profile")}
                className="px-8 py-3 bg-gray-200 text-gray-900 font-bold rounded-lg hover:bg-gray-300 transition"
              >
                Back to Profile
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* SUCCESS MESSAGE */}
      {showSuccessMessage && (
        <div className="fixed bottom-4 right-4 bg-green-500 text-white px-6 py-4 rounded-lg shadow-lg flex items-center gap-3 z-40 animate-in fade-in duration-300">
          <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
          </svg>
          <span className="font-semibold">Settings saved successfully!</span>
        </div>
      )}

      <Footer />
    </div>
  );
}
