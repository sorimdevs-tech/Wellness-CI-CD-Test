import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useUser } from "../context/UserContext";
import { useAppointment } from "../context/AppointmentContext";
import BookingModal from "../components/BookingModal";

interface Hospital {
  id: number;
  name: string;
  status: string;
  distance: number;
  address: string;
  specialties: string[];
  doctors: { name: string; status: string; id?: string }[];
  rating: number;
  reviews: number;
}

export default function BrowseHospitalsPage() {
  const navigate = useNavigate();
  const { user, logout } = useUser();
  const { getNotifications } = useAppointment();
  const [showFilters, setShowFilters] = useState(false);
  const [location, setLocation] = useState("Chennai");
  const [distance, setDistance] = useState(10);
  const [searchTerm, setSearchTerm] = useState("");
  const [hospitals, setHospitals] = useState<Hospital[]>([]);
  const [showBookingModal, setShowBookingModal] = useState(false);
  const [selectedDoctor, setSelectedDoctor] = useState<{
    id: string;
    name: string;
    specialty: string;
  } | null>(null);
  const [bookingSuccess, setBookingSuccess] = useState(false);

  const userNotifications = user ? getNotifications(user.id || "", "user") : [];
  const unreadCount = userNotifications.filter((n) => !n.read).length;

  // Sample dummy data
  const sampleHospitals = [
    {
      id: 1,
      name: "Expresscare Medical Clinic",
      status: "Open",
      distance: 2.4,
      address: "Greams Road, Chennai",
      specialties: ["Cardiology", "Orthopedic", "Neuro"],
      doctors: [
        { name: "Erica Lim", status: "Not Serving Patient" },
        { name: "Nick Young", status: "Not Confirmed", id: "892754961" },
        { name: "Kevin Zane", status: "Serving patient" },
        { name: "Alina Choo", status: "Not Confirmed", id: "891911250" },
      ],
      rating: 4.8,
      reviews: 320,
    },
    {
      id: 2,
      name: "Fortis Malar Hospital",
      status: "Open",
      distance: 4.8,
      address: "Adyar, Chennai",
      specialties: ["Heart Care", "ICU", "General"],
      doctors: [
        { name: "Dr. Rajesh Kumar", status: "Available", id: "doc_001" },
        { name: "Dr. Priya Singh", status: "Available", id: "doc_002" },
      ],
      rating: 4.6,
      reviews: 285,
    },
    {
      id: 3,
      name: "SIMS Hospital",
      status: "Open",
      distance: 6.5,
      address: "Vadapalani, Chennai",
      specialties: ["Emergency", "Dermatology", "Surgery"],
      doctors: [
        { name: "Dr. Amit Patel", status: "Available" },
        { name: "Dr. Neha Gupta", status: "In Emergency" },
      ],
      rating: 4.5,
      reviews: 210,
    },
    {
      id: 4,
      name: "Apollo Hospitals",
      status: "Open",
      distance: 3.2,
      address: "Thousand Lights, Chennai",
      specialties: ["Neurology", "Pediatrics", "Oncology"],
      doctors: [
        { name: "Dr. Vikram Sharma", status: "Available" },
        { name: "Dr. Anjali Roy", status: "Available" },
      ],
      rating: 4.9,
      reviews: 450,
    },
  ];

  useEffect(() => {
    let filtered = sampleHospitals.filter(
      (h) => h.distance <= distance && h.name.toLowerCase().includes(searchTerm.toLowerCase())
    );
    setHospitals(filtered);
  }, [distance, searchTerm]);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* HEADER */}
      <header className="sticky top-0 z-50 bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-8">
          <div className="flex items-center justify-between h-20">
            <button
              onClick={() => navigate("/dashboard")}
              className="flex items-center gap-3 hover:opacity-80 transition"
            >
              <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-emerald-500 rounded-xl flex items-center justify-center shadow-lg">
                <svg className="w-7 h-7 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                </svg>
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Browse Doctors</h1>
                <p className="text-xs text-gray-500">Wellness Dev</p>
              </div>
            </button>

            {/* Search Bar - Center */}
            <div className="hidden lg:flex flex-1 max-w-md mx-8">
              <div className="relative w-full">
                <svg className="absolute left-3 top-3 w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
                <input
                  type="text"
                  placeholder="Search doctors, hospitals..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 bg-gray-100 hover:bg-gray-200 focus:bg-white border border-transparent focus:border-blue-500 rounded-lg focus:outline-none transition"
                />
              </div>
            </div>

            {/* Right Actions */}
            <div className="flex items-center gap-3">
              <button
                onClick={() => {}}
                className="relative p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition"
                title="Notifications"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                </svg>
                {unreadCount > 0 && (
                  <span className="absolute top-1 right-1 w-4 h-4 bg-red-500 text-white text-xs font-bold rounded-full flex items-center justify-center">
                    {unreadCount}
                  </span>
                )}
              </button>

              <div className="relative group">
                <button className="flex items-center gap-2 p-2 text-gray-700 hover:bg-gray-100 rounded-lg transition">
                  <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-emerald-500 rounded-full flex items-center justify-center">
                    <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" />
                    </svg>
                  </div>
                  <span className="hidden sm:inline text-sm font-medium text-gray-700">{user?.name || "User"}</span>
                </button>
              </div>

              <button
                onClick={() => logout()}
                className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition"
                title="Logout"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                </svg>
              </button>
            </div>
          </div>

          {/* Mobile Search Bar */}
          <div className="lg:hidden pb-4">
            <div className="relative">
              <svg className="absolute left-3 top-3 w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
              <input
                type="text"
                placeholder="Search..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 bg-gray-100 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <button
                onClick={() => setShowFilters(!showFilters)}
                className="absolute right-3 top-2.5 text-gray-400 hover:text-gray-600 transition"
                title="Toggle Filters"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z" />
                </svg>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* MAIN CONTENT */}
      <div className="max-w-7xl mx-auto p-8">
        {/* FILTERS SECTION */}
        <div className="bg-white rounded-2xl shadow-lg mb-8 border border-gray-200 overflow-hidden">
          <button
            onClick={() => setShowFilters(!showFilters)}
            className="w-full px-6 py-4 flex items-center justify-between hover:bg-gray-50 transition"
          >
            <div className="flex items-center gap-3">
              <svg className="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z" />
              </svg>
              <h3 className="font-bold text-gray-900">Refine Search</h3>
              {(location !== "Chennai" || distance !== 10) && (
                <span className="ml-2 px-2 py-1 bg-blue-100 text-blue-700 text-xs font-semibold rounded-full">
                  {location !== "Chennai" ? "1" : "0"} filters
                </span>
              )}
            </div>
            <svg className={`w-5 h-5 text-gray-600 transition transform ${showFilters ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" d="M19 14l-7 7m0 0l-7-7m7 7V3" />
            </svg>
          </button>

          {showFilters && (
            <div className="px-6 py-6 border-t border-gray-200 bg-gray-50 animate-in fade-in duration-200">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-3">📍 Location</label>
                  <input
                    type="text"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Enter city"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-3">📏 Distance Range</label>
                  <div className="space-y-2">
                    <input
                      type="range"
                      min="1"
                      max="50"
                      value={distance}
                      onChange={(e) => setDistance(Number(e.target.value))}
                      className="w-full"
                    />
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-gray-600">1 km</span>
                      <span className="text-sm font-bold text-blue-600">{distance} km</span>
                      <span className="text-xs text-gray-600">50 km</span>
                    </div>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-3">🏥 Hospital Type</label>
                  <select className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                    <option>All Types</option>
                    <option>Multi-specialty</option>
                    <option>Clinic</option>
                    <option>Diagnostic Center</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-3">⭐ Rating</label>
                  <select className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                    <option>All Ratings</option>
                    <option>4.5+ Stars</option>
                    <option>4.0+ Stars</option>
                    <option>3.5+ Stars</option>
                  </select>
                </div>
              </div>
              <div className="mt-6 flex gap-3">
                <button className="flex-1 px-4 py-2.5 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 transition">
                  Apply Filters
                </button>
                <button
                  onClick={() => {
                    setLocation("Chennai");
                    setDistance(10);
                  }}
                  className="px-4 py-2.5 border border-gray-300 text-gray-700 font-semibold rounded-lg hover:bg-gray-100 transition"
                >
                  Reset
                </button>
              </div>
            </div>
          )}
        </div>

        {/* HOSPITALS GRID */}
        <div className="space-y-6">
          {hospitals.length > 0 ? (
            hospitals.map((hospital) => (
              <div
                key={hospital.id}
                className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition cursor-pointer border border-gray-200"
              >
                <div className="flex">
                  {/* LEFT SECTION - HOSPITAL INFO (30%) */}
                  <div className="w-3/10 p-6 border-r border-gray-200 bg-gray-50">
                    <h3 className="text-2xl font-bold text-gray-900 mb-2">{hospital.name}</h3>
                    <p className="text-gray-600 mb-4 text-sm">{hospital.address}</p>
                    
                    {/* RATING AND DISTANCE */}
                    <div className="mb-4">
                      <div className="flex items-center gap-1 mb-2">
                        <svg className="w-5 h-5 text-yellow-400" fill="currentColor" viewBox="0 0 20 20">
                          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                        </svg>
                        <span className="font-semibold text-gray-900">{hospital.rating}</span>
                        <span className="text-gray-600 text-sm">({hospital.reviews} reviews)</span>
                      </div>
                      <div className="text-gray-600 text-sm">
                        <span className="font-semibold text-blue-600">{hospital.distance} km</span> away
                      </div>
                    </div>

                    {/* SPECIALTIES */}
                    <div className="flex flex-wrap gap-2">
                      {hospital.specialties.map((specialty, idx) => (
                        <span
                          key={idx}
                          className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-xs font-semibold"
                        >
                          {specialty}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* RIGHT SECTION - POPULAR DOCTOR CARD (70%) */}
                  <div className="w-7/10 p-6 flex items-center justify-center">
                    {hospital.doctors.length > 0 && (
                      <div className="w-full bg-white rounded-xl p-6 border border-gray-200">
                        {/* Doctor Header with Avatar and Verification */}
                        <div className="flex gap-4 mb-4">
                          {/* Doctor Avatar */}
                          <div className="w-24 h-24 bg-gradient-to-br from-blue-600 to-emerald-500 rounded-lg flex-shrink-0 flex items-center justify-center shadow-lg">
                            <svg className="w-12 h-12 text-white" fill="currentColor" viewBox="0 0 20 20">
                              <path d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" />
                            </svg>
                          </div>

                          {/* Doctor Basic Info */}
                          <div className="flex-1">
                            <h4 className="font-bold text-gray-900 text-lg">{hospital.doctors[0].name}</h4>
                            <p className="text-xs text-gray-600 mt-1 leading-tight">
                              MBBS, Specialization in {hospital.specialties[0]}
                            </p>
                            <p className="text-xs text-gray-600 mt-1">{hospital.specialties[0]}</p>
                            <p className="text-xs text-gray-600 mt-1">15+ Years Experience</p>
                            <div className="flex items-center gap-1 mt-2">
                              <span className="inline-flex items-center gap-1 text-xs font-semibold text-green-700">
                                <svg className="w-4 h-4 text-green-600" fill="currentColor" viewBox="0 0 20 20">
                                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                                </svg>
                                Medical Registration Verified
                              </span>
                            </div>
                          </div>
                        </div>

                        {/* Doctor Description */}
                        <p className="text-sm text-gray-700 mt-4 mb-4 line-clamp-3">
                          {hospital.doctors[0].name} is a specialist {hospital.specialties[0]} with passion for providing quality care. Experienced in latest medical techniques and patient-centric approach.
                        </p>

                        {/* Book Button */}
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedDoctor({
                              id: hospital.doctors[0].id || "doc_0",
                              name: hospital.doctors[0].name,
                              specialty: hospital.specialties[0],
                            });
                            setShowBookingModal(true);
                          }}
                          className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:opacity-90 text-white font-semibold py-2 rounded-lg transition"
                        >
                          Book
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                {/* OTHER DOCTORS - LIMIT TO 2 CARDS */}
                {hospital.doctors.length > 1 && (
                  <div className="p-6 border-t border-gray-200 bg-gray-50">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {hospital.doctors.slice(1, 3).map((doctor, idx) => (
                        <div key={idx} className="bg-gradient-to-br from-blue-50 to-emerald-50 p-4 rounded-xl">
                          <div className="flex items-center justify-between mb-3">
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-emerald-500 rounded-full"></div>
                              <div>
                                <p className="font-semibold text-gray-900 text-sm">{doctor.name}</p>
                                <p className="text-xs text-gray-600">{doctor.status}</p>
                              </div>
                            </div>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setSelectedDoctor({
                                  id: doctor.id || `doc_${idx}`,
                                  name: doctor.name,
                                  specialty: hospital.specialties[0],
                                });
                                setShowBookingModal(true);
                              }}
                              className="px-2 py-1 bg-blue-600 text-white text-xs font-semibold rounded-lg hover:bg-blue-700 transition"
                            >
                              Book
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))
          ) : (
            <div className="bg-white rounded-2xl p-12 text-center">
              <svg className="w-16 h-16 text-gray-300 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" d="M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2z" />
              </svg>
              <p className="text-gray-600 text-lg">No hospitals found in your search</p>
            </div>
          )}
        </div>
      </div>

      {/* BOOKING MODAL */}
      {selectedDoctor && (
        <BookingModal
          isOpen={showBookingModal}
          doctor={selectedDoctor}
          onClose={() => {
            setShowBookingModal(false);
            setSelectedDoctor(null);
          }}
          onSuccess={() => {
            setBookingSuccess(true);
            setTimeout(() => setBookingSuccess(false), 3000);
          }}
        />
      )}

      {/* SUCCESS TOAST */}
      {bookingSuccess && (
        <div className="fixed bottom-4 right-4 bg-green-500 text-white px-6 py-4 rounded-lg shadow-lg flex items-center gap-3 z-40">
          <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
          </svg>
          <span className="font-semibold">Appointment booked successfully!</span>
        </div>
      )}
    </div>
  );
}
