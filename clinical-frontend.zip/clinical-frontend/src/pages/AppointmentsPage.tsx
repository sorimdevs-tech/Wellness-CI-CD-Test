import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useUser } from "../context/UserContext";
import { useAppointment } from "../context/AppointmentContext";
import BookingModal from "../components/BookingModal";

interface Appointment {
  id: string;
  doctorName: string;
  specialty: string;
  hospital: string;
  date: string;
  time: string;
  status: "scheduled" | "upcoming" | "completed" | "cancelled";
  notes?: string;
  consultationType: "In-Person" | "Video Call" | "Phone";
}

export default function AppointmentsPage() {
  const navigate = useNavigate();
  const { user, logout } = useUser();
  const { getNotifications } = useAppointment();
  const [activeTab, setActiveTab] = useState<"scheduled" | "upcoming" | "completed" | "book">("upcoming");
  const [showBookingModal, setShowBookingModal] = useState(false);
  const [selectedDoctor, setSelectedDoctor] = useState<{
    id: string;
    name: string;
    specialty: string;
  } | null>(null);

  const userNotifications = user ? getNotifications(user.id || "", "user") : [];
  const unreadCount = userNotifications.filter((n) => !n.read).length;

  // Sample appointment data
  const appointments: Appointment[] = [
    {
      id: "1",
      doctorName: "Dr. Rajesh Kumar",
      specialty: "Cardiology",
      hospital: "Fortis Malar Hospital",
      date: "Dec 20, 2024",
      time: "2:30 PM",
      status: "scheduled",
      consultationType: "In-Person",
      notes: "Regular checkup for heart condition",
    },
    {
      id: "2",
      doctorName: "Dr. Priya Singh",
      specialty: "Orthopedic",
      hospital: "Apollo Hospitals",
      date: "Dec 15, 2024",
      time: "10:00 AM",
      status: "upcoming",
      consultationType: "In-Person",
      notes: "Follow-up consultation",
    },
    {
      id: "3",
      doctorName: "Dr. Arjun Menon",
      specialty: "General Medicine",
      hospital: "SIMS Hospital",
      date: "Dec 10, 2024",
      time: "4:15 PM",
      status: "completed",
      consultationType: "Video Call",
      notes: "General health check",
    },
    {
      id: "4",
      doctorName: "Dr. Vikram Sharma",
      specialty: "Neurology",
      hospital: "Apollo Hospitals",
      date: "Dec 22, 2024",
      time: "11:00 AM",
      status: "scheduled",
      consultationType: "Phone",
      notes: "Consultation for headaches",
    },
    {
      id: "5",
      doctorName: "Dr. Anjali Roy",
      specialty: "Pediatrics",
      hospital: "Apollo Hospitals",
      date: "Dec 18, 2024",
      time: "3:00 PM",
      status: "upcoming",
      consultationType: "In-Person",
      notes: "Child wellness checkup",
    },
    {
      id: "6",
      doctorName: "Dr. Neha Gupta",
      specialty: "Dermatology",
      hospital: "SIMS Hospital",
      date: "Dec 05, 2024",
      time: "5:30 PM",
      status: "completed",
      consultationType: "In-Person",
      notes: "Skin treatment follow-up",
    },
  ];

  const filterAppointments = (status: "scheduled" | "upcoming" | "completed" | "book") => {
    if (status === "book") return [];
    return appointments.filter((apt) => apt.status === status);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "scheduled":
        return "bg-yellow-100 text-yellow-700 border-yellow-300";
      case "upcoming":
        return "bg-blue-100 text-blue-700 border-blue-300";
      case "completed":
        return "bg-green-100 text-green-700 border-green-300";
      case "cancelled":
        return "bg-red-100 text-red-700 border-red-300";
      default:
        return "bg-gray-100 text-gray-700 border-gray-300";
    }
  };

  const getConsultationIcon = (type: string) => {
    switch (type) {
      case "In-Person":
        return "🏥";
      case "Video Call":
        return "📹";
      case "Phone":
        return "📞";
      default:
        return "📋";
    }
  };

  const renderAppointmentsList = () => {
    const filtered = filterAppointments(activeTab as any);

    if (activeTab === "book") {
      return (
        <div className="max-w-4xl mx-auto">
          <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-2xl p-12 text-center border-2 border-blue-200">
            <svg className="w-20 h-20 text-blue-600 mx-auto mb-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
            </svg>
            <h3 className="text-2xl font-bold text-gray-900 mb-2">Book New Appointment</h3>
            <p className="text-gray-600 mb-8">Select a doctor below to schedule your appointment</p>
            <button
              onClick={() => navigate("/browse-hospitals")}
              className="inline-block px-8 py-3 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 transition"
            >
              Browse Doctors & Hospitals
            </button>
          </div>
        </div>
      );
    }

    if (filtered.length === 0) {
      return (
        <div className="bg-white rounded-2xl p-12 text-center border border-gray-200">
          <svg className="w-16 h-16 text-gray-300 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          <p className="text-gray-600 text-lg">
            {activeTab === "scheduled" && "No scheduled appointments"}
            {activeTab === "upcoming" && "No upcoming appointments"}
            {activeTab === "completed" && "No completed appointments"}
          </p>
        </div>
      );
    }

    return (
      <div className="space-y-4">
        {filtered.map((appointment) => (
          <div
            key={appointment.id}
            className="bg-white rounded-2xl p-6 shadow-lg border border-gray-200 hover:shadow-xl transition"
          >
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
              {/* Left: Doctor Info */}
              <div className="flex-1">
                <div className="flex items-start gap-4 mb-4">
                  <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-emerald-500 rounded-xl flex items-center justify-center flex-shrink-0">
                    <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" />
                    </svg>
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-gray-900">{appointment.doctorName}</h3>
                    <p className="text-sm text-gray-600">{appointment.specialty}</p>
                    <p className="text-xs text-gray-500 mt-1">{appointment.hospital}</p>
                  </div>
                </div>
                {appointment.notes && (
                  <div className="text-sm text-gray-600 bg-gray-50 p-3 rounded-lg">
                    <span className="font-semibold">Notes:</span> {appointment.notes}
                  </div>
                )}
              </div>

              {/* Middle: Date & Time */}
              <div className="flex-1 md:text-center">
                <div className="space-y-2">
                  <div>
                    <p className="text-xs text-gray-500 font-semibold uppercase">Date</p>
                    <p className="text-lg font-bold text-gray-900">{appointment.date}</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500 font-semibold uppercase">Time</p>
                    <p className="text-lg font-bold text-gray-900">{appointment.time}</p>
                  </div>
                  <div className="flex items-center justify-center gap-2 mt-3">
                    <span className="text-xl">{getConsultationIcon(appointment.consultationType)}</span>
                    <span className="text-xs font-semibold text-gray-600">{appointment.consultationType}</span>
                  </div>
                </div>
              </div>

              {/* Right: Status & Actions */}
              <div className="flex flex-col items-start md:items-end gap-4">
                <span className={`px-4 py-2 rounded-full text-sm font-semibold border ${getStatusColor(appointment.status)}`}>
                  {appointment.status.charAt(0).toUpperCase() + appointment.status.slice(1)}
                </span>
                <div className="flex gap-2 w-full md:w-auto">
                  {appointment.status !== "completed" && appointment.status !== "cancelled" && (
                    <>
                      <button className="flex-1 md:flex-none px-4 py-2 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 transition text-sm">
                        Reschedule
                      </button>
                      <button className="flex-1 md:flex-none px-4 py-2 border border-red-300 text-red-600 font-semibold rounded-lg hover:bg-red-50 transition text-sm">
                        Cancel
                      </button>
                    </>
                  )}
                  {appointment.status === "upcoming" && (
                    <button className="flex-1 md:flex-none px-4 py-2 bg-green-600 text-white font-semibold rounded-lg hover:bg-green-700 transition text-sm">
                      Join Video
                    </button>
                  )}
                  {appointment.status === "completed" && (
                    <button className="flex-1 md:flex-none px-4 py-2 border border-gray-300 text-gray-700 font-semibold rounded-lg hover:bg-gray-50 transition text-sm">
                      View Report
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* HEADER */}
      <header className="sticky top-0 z-50 bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-8">
          <div className="flex items-center justify-between h-20">
            <button
              onClick={() => navigate("/dashboard")}
              className="flex items-center gap-3 hover:opacity-80 transition"
            >
              <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-emerald-500 rounded-xl flex items-center justify-center shadow-lg">
                <svg className="w-7 h-7 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                </svg>
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">My Appointments</h1>
                <p className="text-xs text-gray-500">Wellness Dev</p>
              </div>
            </button>

            <div className="flex items-center gap-3">
              <button
                onClick={() => {}}
                className="relative p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                </svg>
                {unreadCount > 0 && (
                  <span className="absolute top-1 right-1 w-4 h-4 bg-red-500 text-white text-xs font-bold rounded-full flex items-center justify-center">
                    {unreadCount}
                  </span>
                )}
              </button>

              <div className="relative group">
                <button className="flex items-center gap-2 p-2 text-gray-700 hover:bg-gray-100 rounded-lg transition">
                  <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-emerald-500 rounded-full flex items-center justify-center">
                    <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" />
                    </svg>
                  </div>
                  <span className="hidden sm:inline text-sm font-medium text-gray-700">{user?.name || "User"}</span>
                </button>
              </div>

              <button
                onClick={() => logout()}
                className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition"
                title="Logout"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                </svg>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* TABS */}
      <div className="bg-white border-b border-gray-200 sticky top-20 z-40">
        <div className="max-w-7xl mx-auto px-8">
          <div className="flex gap-8">
            {[
              { id: "scheduled", label: "Scheduled", icon: "📅", count: filterAppointments("scheduled").length },
              { id: "upcoming", label: "Upcoming", icon: "⏰", count: filterAppointments("upcoming").length },
              { id: "completed", label: "Completed", icon: "✅", count: filterAppointments("completed").length },
              { id: "book", label: "Book Appointment", icon: "➕", count: 0 },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-4 py-4 font-semibold border-b-2 transition whitespace-nowrap ${
                  activeTab === tab.id
                    ? "text-blue-600 border-blue-600"
                    : "text-gray-600 border-transparent hover:text-gray-900"
                }`}
              >
                <span className="text-lg">{tab.icon}</span>
                <span>{tab.label}</span>
                {tab.count > 0 && tab.id !== "book" && (
                  <span className="ml-2 px-2 py-0.5 bg-blue-100 text-blue-700 text-xs font-bold rounded-full">
                    {tab.count}
                  </span>
                )}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* CONTENT */}
      <div className="max-w-7xl mx-auto px-8 py-8">
        {renderAppointmentsList()}
      </div>

      {/* BOOKING MODAL */}
      {selectedDoctor && (
        <BookingModal
          isOpen={showBookingModal}
          doctor={selectedDoctor}
          onClose={() => {
            setShowBookingModal(false);
            setSelectedDoctor(null);
          }}
          onSuccess={() => {}}
        />
      )}
    </div>
  );
}
