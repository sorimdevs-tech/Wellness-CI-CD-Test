import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useUser } from "../context/UserContext";

export default function Register() {
  const navigate = useNavigate();
  const { setUser } = useUser();

  const [name, setName] = useState("");
  const [countryCode, setCountryCode] = useState("+91");
  const [mobile, setMobile] = useState("");
  const [otp, setOtp] = useState("");
  const [otpSent, setOtpSent] = useState(false);
  const [dob, setDob] = useState("");
  const [age, setAge] = useState("");
  const [email, setEmail] = useState("");
  const [gender, setGender] = useState("");
  const [isDoctor, setIsDoctor] = useState(false);
  const [regNumber, setRegNumber] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  /* ---------------- AGE CALCULATION ---------------- */
  const calculateAge = (date: string) => {
    const birthDate = new Date(date);
    if (!birthDate.getTime()) return;

    const diff = Date.now() - birthDate.getTime();
    const ageDate = new Date(diff);
    setAge(String(ageDate.getUTCFullYear() - 1970));
  };

  /* ---------------- SEND OTP ---------------- */
  const sendOtp = () => {
    setError("");

    // Validate name
    if (!name.trim()) {
      setError("Please enter your full name");
      return;
    }

    // Validate mobile number
    if (!mobile.match(/^\d{10}$/)) {
      setError("Please enter a valid 10-digit mobile number");
      return;
    }

    // Validate email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email.trim()) {
      setError("Please enter your email address");
      return;
    }
    if (!emailRegex.test(email)) {
      setError("Please enter a valid email address (e.g., user@example.com)");
      return;
    }

    setLoading(true);

    setTimeout(() => {
      setOtpSent(true);
      setLoading(false);

      // Auto-fill OTP for testing
      setTimeout(() => setOtp("123456"), 1000);

    }, 1200);
  };

  /* ---------------- REGISTER ---------------- */
  const handleRegister = () => {
    setError("");

    // Validate name
    if (!name.trim()) {
      setError("Please enter your full name");
      return;
    }

    // Validate mobile number
    if (!mobile.match(/^\d{10}$/)) {
      setError("Please enter a valid 10-digit mobile number");
      return;
    }

    // Validate email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email.trim()) {
      setError("Please enter your email address");
      return;
    }
    if (!emailRegex.test(email)) {
      setError("Please enter a valid email address (e.g., user@example.com)");
      return;
    }

    // Validate DOB
    if (!dob) {
      setError("Please select your date of birth");
      return;
    }

    // Validate gender
    if (!gender) {
      setError("Please select your gender");
      return;
    }

    // Validate doctor registration number if doctor
    if (isDoctor && !regNumber.trim()) {
      setError("Please enter your Medical Registration Number");
      return;
    }

    // Validate OTP
    if (otp !== "123456") {
      setError("Invalid OTP, please try again.");
      return;
    }

    setLoading(true);
    setTimeout(() => {
      const userType = isDoctor ? "doctor" : "user";
      
      // Save to localStorage
      localStorage.setItem("userType", userType);
      localStorage.setItem("userName", name);
      localStorage.setItem("userEmail", email);
      localStorage.setItem("userMobile", mobile);
      localStorage.setItem("currentRole", userType);
      if (isDoctor && regNumber) {
        localStorage.setItem("regNumber", regNumber);
      }
      
      // Update context
      setUser({
        name,
        email,
        mobile,
        userType: userType as "user" | "doctor",
        currentRole: userType as "user" | "doctor",
        regNumber: isDoctor ? regNumber : undefined,
      });
      
      navigate("/dashboard");
    }, 800);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-emerald-50 flex items-center justify-center p-6">
      <div className="max-w-lg w-full backdrop-blur-xl bg-white/60 border border-white/40 rounded-3xl p-10 shadow-xl">

        {/* HEADER */}
        <div className="text-center mb-8">
          <div className="w-20 h-20 mx-auto bg-gradient-to-br from-blue-600 to-emerald-500 rounded-full flex items-center justify-center shadow-lg">
            <svg className="w-10 h-10 text-white" fill="none" viewBox="0 0 24 24">
              <path stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" d="M12 6v12m6-6H6"/>
            </svg>
          </div>
          <h1 className="mt-4 text-4xl font-extrabold bg-gradient-to-r from-blue-700 to-emerald-600 text-transparent bg-clip-text">
            Wellness Dev
          </h1>
          <p className="text-gray-600 mt-1">Create Account - By Sorim AI</p>
        </div>

        {/* USER TYPE SELECTION - RADIO BUTTONS */}
        <div className="mb-8 p-4 bg-blue-50 rounded-2xl border border-blue-200">
          <p className="text-sm font-semibold text-gray-700 mb-4">I am a:</p>
          <div className="space-y-3">
            {/* User Radio Button */}
            <label className="flex items-center cursor-pointer p-3 rounded-lg hover:bg-blue-100 transition">
              <input
                type="radio"
                name="userType"
                value="user"
                checked={isDoctor === false}
                onChange={() => setIsDoctor(false)}
                className="w-4 h-4 text-blue-600 cursor-pointer"
              />
              <span className="ml-3 text-sm font-medium text-gray-800">👤 Patient/User</span>
            </label>

            {/* Doctor Radio Button */}
            <label className="flex items-center cursor-pointer p-3 rounded-lg hover:bg-blue-100 transition">
              <input
                type="radio"
                name="userType"
                value="doctor"
                checked={isDoctor === true}
                onChange={() => setIsDoctor(true)}
                className="w-4 h-4 text-blue-600 cursor-pointer"
              />
              <span className="ml-3 text-sm font-medium text-gray-800">👨‍⚕️ Doctor</span>
            </label>
          </div>
        </div>

        {/* ERROR BLOCK */}
        {error && (
          <div className="mb-6 p-4 bg-red-100 border border-red-300 rounded-xl text-sm text-red-700 flex gap-3">
            <svg className="w-5 h-5 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
              <path d="M10 18a8 8 0 100-16 8 8 0 000 16zm-1-11h2v5h-2V7zm0 6h2v2h-2v-2z"/>
            </svg>
            {error}
          </div>
        )}

        {/* NAME */}
        <div className="mb-5">
          <label className="text-sm font-semibold text-gray-700 mb-2 block">Full Name</label>
          <input
            type="text"
            className="w-full py-3 px-4 rounded-xl border border-gray-300 focus:ring-2 focus:ring-blue-500"
            placeholder="Enter your full name"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
        </div>

        {/* MOBILE + COUNTRY CODE */}
        {!otpSent && (
          <div className="mb-5">
            <label className="text-sm font-semibold text-gray-700 mb-2 block">Mobile Number</label>

            <div className="flex gap-3">
              <select
                className="w-28 py-3 px-3 border border-gray-300 rounded-xl bg-white focus:ring-2 focus:ring-blue-500"
                value={countryCode}
                onChange={(e) => setCountryCode(e.target.value)}
              >
                <option value="+91">🇮🇳 +91</option>
                <option value="+1">🇺🇸 +1</option>
                <option value="+44">🇬🇧 +44</option>
                <option value="+61">🇦🇺 +61</option>
              </select>

              <input
                type="text"
                maxLength={10}
                className="flex-1 py-3 px-4 rounded-xl border border-gray-300 focus:ring-2 focus:ring-blue-500"
                placeholder="10-digit mobile number"
                value={mobile}
                onChange={(e) => setMobile(e.target.value)}
              />
            </div>

            <button
              onClick={sendOtp}
              disabled={loading}
              className="w-full mt-4 py-3 rounded-xl bg-gradient-to-r from-blue-600 to-blue-700 text-white font-semibold hover:opacity-90 shadow-md flex items-center justify-center"
            >
              {loading ? (
                <div className="flex items-center gap-2">
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  Sending OTP...
                </div>
              ) : (
                "Verify Mobile"
              )}
            </button>
          </div>
        )}

        {/* OTP FIELD */}
        {otpSent && (
          <div className="mb-5">
            <label className="text-sm font-semibold text-gray-700 mb-2 block">Enter OTP</label>
            <input
              type="text"
              maxLength={6}
              className="w-full py-3 px-4 text-center text-xl tracking-widest rounded-xl border border-gray-300 focus:ring-2 focus:ring-green-500"
              placeholder="______"
              value={otp}
              onChange={(e) => setOtp(e.target.value)}
            />

            <p className="text-xs text-gray-600 text-center mt-2">
              OTP sent to <strong>{countryCode} {mobile}</strong>
            </p>
            <button
              onClick={() => setOtp("")}
              className="block mx-auto mt-2 text-blue-600 text-sm hover:underline"
            >
              Resend OTP
            </button>
          </div>
        )}

        {/* DOB + AGE */}
        <div className="mb-5 flex gap-4">
          <div className="flex-1">
            <label className="text-sm font-semibold text-gray-700 mb-2 block">Date of Birth</label>
            <input
              type="date"
              className="w-full py-3 px-4 rounded-xl border border-gray-300 focus:ring-2 focus:ring-blue-500"
              value={dob}
              onChange={(e) => {
                setDob(e.target.value);
                calculateAge(e.target.value);
              }}
            />
          </div>

          <div>
            <label className="text-sm font-semibold text-gray-700 mb-2 block">Age</label>
            <input
              type="text"
              className="w-24 py-3 text-center rounded-xl bg-gray-100 border border-gray-300"
              value={age}
              readOnly
            />
          </div>
        </div>

        {/* EMAIL */}
        <div className="mb-5">
          <label className="text-sm font-semibold text-gray-700 mb-2 block">Email</label>
          <input
            type="email"
            className="w-full py-3 px-4 rounded-xl border border-gray-300 focus:ring-2 focus:ring-blue-500"
            placeholder="Enter email address"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>

        {/* GENDER */}
        <div className="mb-5">
          <label className="text-sm font-semibold text-gray-700 mb-2 block">Gender</label>
          <select
            className="w-full py-3 px-4 rounded-xl border border-gray-300 focus:ring-2 focus:ring-blue-500 bg-white"
            value={gender}
            onChange={(e) => setGender(e.target.value)}
          >
            <option value="">Select gender</option>
            <option value="male">Male</option>
            <option value="female">Female</option>
            <option value="other">Others</option>
          </select>
        </div>

        {/* REGISTRATION NUMBER FIELD (IF DOCTOR) */}
        {isDoctor && (
          <div className="mb-5">
            <label className="text-sm font-semibold text-gray-700 mb-2 block">
              Medical Registration Number
            </label>
            <input
              type="text"
              className="w-full py-3 px-4 rounded-xl border border-gray-300 focus:ring-2 focus:ring-emerald-500"
              placeholder="Enter registration number"
              value={regNumber}
              onChange={(e) => setRegNumber(e.target.value)}
            />
          </div>
        )}

        {/* SUBMIT */}
        <button
          onClick={handleRegister}
          disabled={loading}
          className="w-full py-3 bg-gradient-to-r from-emerald-600 to-emerald-700 hover:opacity-90 text-white font-semibold rounded-xl shadow-md flex items-center justify-center"
        >
          {loading ? (
            <div className="flex items-center gap-2">
              <div className="animate-spin w-5 h-5 border-2 border-white border-t-transparent rounded-full"></div>
              Creating Account...
            </div>
          ) : (
            "Register"
          )}
        </button>

        {/* ALREADY HAVE ACCOUNT */}
        <p className="text-center text-sm text-gray-600 mt-4">
          Already registered?{" "}
          <span className="text-blue-600 hover:underline cursor-pointer" onClick={() => navigate("/")}>
            Login here
          </span>
        </p>

        {/* FOOTER - SORIM TECHNOLOGY */}
        <div className="mt-8 pt-6 border-t border-gray-200 text-center">
          <p className="text-xs text-gray-500">
            Developed by <span className="font-semibold text-gray-700">Sorim Technology</span>
          </p>
          <p className="text-xs text-gray-400 mt-1">© 2025 Wellness Dev. All rights reserved.</p>
        </div>
      </div>
    </div>
  );
}
